package clb.com.tangcco058_21.service;


import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_21.R;

/**
 * Created by cuilibao on 2017/9/22.
 */

public class MyService02 extends Service {

    private List<Bitmap> mBitmaps = new ArrayList<>();
    private boolean flag = true;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        while (flag) {
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.aa);
            mBitmaps.add(bitmap);
        }
        //下载文件 成功 关掉Service
        //stopSelf();

        //只会重启一次
        return START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}

package clb.com.tangcco058_21;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import clb.com.tangcco058_21.service.MyService01;
import clb.com.tangcco058_21.service.MyService02;

public class MainActivity extends AppCompatActivity {

    private Intent mIntent;
    private boolean flag = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void start(View view) {
        //
        mIntent = new Intent(this, MyService01.class);
        flag = !flag;

        //传值
        mIntent.putExtra("flag", flag);

        startService(mIntent);

    }

    public void close(View view) {
        if (mIntent != null) {
            stopService(mIntent);
        }

    }

    public void startException(View view) {
        Intent intent = new Intent(this, MyService02.class);
        startService(intent);
    }
}

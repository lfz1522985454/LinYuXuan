package clb.com.tangcco058_21;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import clb.com.tangcco058_21.service.MyService03;

public class BindActivity extends AppCompatActivity {
    private MyConn mMyConn;
    private TextView tv_time;
    private MyReceiver mMyReceiver;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind);
        tv_time = (TextView) findViewById(R.id.tv_time);
    }

    public void bind(View view) {
//        startService()
        Intent intent = new Intent(this, MyService03.class);
        mMyConn = new MyConn();
        //BIND_AUTO_CREATE 自动绑定
        bindService(intent, mMyConn, BIND_AUTO_CREATE);
    }

    public void unBind(View view) {
        if (mMyConn != null) {
            unbindService(mMyConn);

        }
    }


    class MyConn implements ServiceConnection {

        /**
         * 服务连接的时候调用
         *
         * @param name
         * @param service
         */
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            //得到MyBinder对象
            MyService03.MyBinder myBinder = (MyService03.MyBinder) service;
            MyService03 service03 = myBinder.getInstance();
            service03.getTime();
//            tv_time.setText(time);

        }

        /**
         * 意外销毁的时候调用
         *
         * @param name
         */
        @Override
        public void onServiceDisconnected(ComponentName name) {

        }

    }


    class MyReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String time = intent.getStringExtra("time");
            tv_time.setText(time);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mMyReceiver = new MyReceiver();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("tcmp058888");
        registerReceiver(mMyReceiver, intentFilter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mMyReceiver != null) {
            unregisterReceiver(mMyReceiver);
        }

    }
}



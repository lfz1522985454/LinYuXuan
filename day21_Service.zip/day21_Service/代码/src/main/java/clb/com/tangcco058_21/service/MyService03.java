package clb.com.tangcco058_21.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.text.format.Time;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by cuilibao on 2017/9/22.
 */

public class MyService03 extends Service {
    private static final String TAG = "TAG";
    private Time mTime;
    private Timer mTimer;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate: ");
        mTime = new Time();
        mTimer = new Timer();
    }

    /**
     * IBinder
     *
     * @param intent
     * @return
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: ");
        return new MyBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "onUnbind: ");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy: ");//i info  e  error  d debug  w warring
    }

    public void getTime() {
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {

                //指定到当前的时间
                mTime.setToNow();

                String time = mTime.hour + ":" + mTime.minute + ":" + mTime.second;

                //发送到Activity
                //广播
                Intent intent = new Intent();
                intent.setAction("tcmp058888");
                intent.putExtra("time", time);
                sendBroadcast(intent);

            }
        }, 0, 500);
        //return time;
    }

    public class MyBinder extends Binder {
        public MyService03 getInstance() {
            return MyService03.this;
        }
    }
}

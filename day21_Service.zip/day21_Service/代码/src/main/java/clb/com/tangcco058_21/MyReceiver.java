package clb.com.tangcco058_21;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by cuilibao on 2017/9/22.
 */
public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //来电话
        //1:打开录音功能
        //2:开始录音
        //3:发送到服务器
    }
}

package clb.com.tangcco058_14;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_14.fragment.Fragment1;
import clb.com.tangcco058_14.fragment.Fragment2;
import clb.com.tangcco058_14.fragment.Fragment3;

public class MainActivity extends AppCompatActivity {
    private ViewPager mViewPager;//List<View>
    //List<Map> 朱晓宇
    //List<Fragment>
    List<Fragment> mFragments = new ArrayList<>();
    private Fragment1 mFragment1;
    private Fragment2 mFragment2;
    private Fragment3 mFragment3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mViewPager = (ViewPager) findViewById(R.id.mViewPager);

        mFragment1 = new Fragment1();
        mFragment2 = new Fragment2();
        mFragment3 = new Fragment3();


        Bundle bundle1 = new Bundle();
        bundle1.putString("value","Fragment1");
        mFragment1.setArguments(bundle1);

        Bundle bundle2 = new Bundle();
        bundle2.putString("value","Fragment2");
        mFragment2.setArguments(bundle2);

        Bundle bundle3 = new Bundle();
        bundle3.putString("value","Fragment3");
        mFragment3.setArguments(bundle3);

        //数据源
        mFragments.add(mFragment1);
        mFragments.add(mFragment2);
        mFragments.add(mFragment3);


        //适配器
        mViewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));



    }

    class MyAdapter extends FragmentPagerAdapter {

        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        /**
         *
         * @param position
         * @return
         */
        @Override
        public Fragment getItem(int position) {//BaseAdapter
            return mFragments.get(position);
        }

        /**
         * 数量
         * @return
         */
        @Override
        public int getCount() {
            return mFragments.size();
        }
    }

}

package clb.com.tangcco058_14;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class NetActivity extends AppCompatActivity {
    private TextView tv_result;
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            int what = msg.what;
            if (what == 1) {
                Toast.makeText(NetActivity.this, "网络异常", Toast.LENGTH_SHORT).show();
                return;
            }
            //接收
            String result = (String) msg.obj;
            tv_result.setText(result);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_net);
        tv_result = (TextView) findViewById(R.id.tv_result);
    }

    public void getNetData(View view) {
        //耗时
        //子线程
        new Thread(new Runnable() {
            @Override
            public void run() {
                //网络操作
                try {
                    //1:URL对象
                    URL url = new URL("http://www.sojson.com/api/qqmusic/8446666");
                    //2:url 创建一个HttpUrlConnection对象
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                    //3:连接对象
                    connection.setRequestMethod("GET");//GET:效率更高  POST:不把参数显示在网页

                    //设置连接超时时间
                    connection.setConnectTimeout(2000);
                    //设置读取超时时间
                    connection.setReadTimeout(2000);


                    //200  404   500
                    //判断返回码
                    if (connection.getResponseCode()==200) {
                        //得到返回结果 流
                        InputStream inputStream = connection.getInputStream();


                        //-->String

                        //1:放到缓冲中
                        //2:缓冲读取

                        //方式二 字符流
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String line = "";
                        StringBuilder stringBuilder = new StringBuilder();
                        while ((line = reader.readLine()) != null) {
                            stringBuilder.append(line);
                        }
                        String result = stringBuilder.toString();
                        Message message = new Message();
                        message.obj = result;
                        mHandler.sendMessage(message);
                        //显示出来
                    }


                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.d("TAG", "错误信息"+e.getMessage());
                    mHandler.sendEmptyMessage(1);
                }

            }
        }).start();
    }

    public void parseJson(View view) {
        //json  网络
        //assets
        try {
            InputStream open = getAssets().open("data.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(open));

            String line = "";
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            String result = stringBuilder.toString();

            //json
            //解析  {}想都别想
            JSONObject jsonObject = new JSONObject(result);
            String name = jsonObject.getString("name");
            int age = jsonObject.getInt("age");

            //数组
            JSONArray data = jsonObject.getJSONArray("result");
            //想都别想 先写一个for循环
            for (int i = 0; i < data.length(); i++) {
                JSONObject object = data.getJSONObject(i);
                String address = object.getString("address");
                //存放到集合中  集合 数据源 适配 -->高级控件
                Toast.makeText(this, address, Toast.LENGTH_SHORT).show();

            }


            Toast.makeText(this, name+":"+age, Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

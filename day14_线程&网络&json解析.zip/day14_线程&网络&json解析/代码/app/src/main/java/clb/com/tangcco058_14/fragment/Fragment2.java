package clb.com.tangcco058_14.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import clb.com.tangcco058_14.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment2 extends Fragment {


    private View mView;
    private TextView mTextView;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_fragment1, container, false);
        mTextView = (TextView) mView.findViewById(R.id.tv_fragment);
        //传过来的值是不是空
        Bundle arguments = getArguments();

        if (arguments!=null) {
            mTextView.setText(arguments.getString("value"));
        }
        return mView;

    }

}

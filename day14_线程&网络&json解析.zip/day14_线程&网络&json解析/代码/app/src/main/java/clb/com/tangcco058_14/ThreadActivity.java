package clb.com.tangcco058_14;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class ThreadActivity extends AppCompatActivity {
    private ImageView img_iv;

    //Handler:线程的魔法师
    Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            //接收子线程传递过来的消息
            //主线程
            Bitmap bitmap = (Bitmap) msg.obj;
            img_iv.setImageBitmap(bitmap);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thread);
        img_iv = (ImageView) findViewById(R.id.img_iv);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS

        }, 1);

    }

    public void startThread(View view) {
        //开一个线程
//        new Thread() {
//            @Override
//            public void run() {
//                super.run();
//                //开启一个子线程
//            }
//        };
        new Thread(new Runnable() {
            @Override
            public void run() {
                //开启一个子线程
                //只要页面发生变化 就属于更新UI

                //Toast.makeText(ThreadActivity.this, "hahahah", Toast.LENGTH_SHORT).show();
                //用途 耗时操作 网络  读取SD


                //怎么传值到主线程
                byte[] fileFromSD = SDUtils.getFileFromSD("abcd.png");
                Bitmap bitmap = BitmapFactory.decodeByteArray(fileFromSD, 0, fileFromSD.length);
                //线程之间传值
                //想要传递的消息
                Message message = new Message();
                message.obj = bitmap;
                mHandler.sendMessage(message);
                //img_iv.setImageBitmap(bitmap);

            }
        }).start();

    }
}

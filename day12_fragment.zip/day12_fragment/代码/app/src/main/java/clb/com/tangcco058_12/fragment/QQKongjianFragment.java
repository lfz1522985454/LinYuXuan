package clb.com.tangcco058_12.fragment;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import clb.com.tangcco058_12.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class QQKongjianFragment extends Fragment {
    private static final String TAG = "TAG";


    private View mView;
    private ListView mListView;


    public QQKongjianFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Log.d(TAG, "onAttach: QQKongjianFragment");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: QQKongjianFragment");
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_qqkongjian, container, false);
        mListView = (ListView) mView.findViewById(R.id.mListView);

        String[] mData = new String[20];
        for (int i = 0; i < 20; i++) {
            mData[i] = "我有" + i + "个老婆";
        }
        Bundle bundle = getArguments();
        if (bundle != null) {
            Toast.makeText(getContext(), bundle.getString("key_qq_kongjian"), Toast.LENGTH_SHORT).show();

        }


        mListView.setAdapter(new ArrayAdapter<String>(
                getContext(),
                android.R.layout.simple_list_item_1,
                mData
        ));


        return mView;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: QQKongjianFragment");

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: QQKongjianFragment");

    }


    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: QQKongjianFragment");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: QQKongjianFragment");

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: QQKongjianFragment");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d(TAG, "onDestroyView: QQKongjianFragment");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.d(TAG, "onDetach: QQKongjianFragment");
    }

}

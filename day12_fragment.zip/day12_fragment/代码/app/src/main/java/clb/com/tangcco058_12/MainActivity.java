package clb.com.tangcco058_12;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import clb.com.tangcco058_12.fragment.MyFragment2;

public class MainActivity extends AppCompatActivity {

    private MyFragment2 mMyFragment2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMyFragment2 = new MyFragment2();
        //app   Support:v4包的FragmentManager 对象
        FragmentManager manager = getSupportFragmentManager();
        //manager 管理栈

        //得到事务对象
        FragmentTransaction ft = manager.beginTransaction();

//        ft.replace()
//
//        ft.hide()
//        ft.show()
//
//        ft.remove()
        ft.add(R.id.container, mMyFragment2);//id:容器的id
        //提交
        ft.commit();



    }
}

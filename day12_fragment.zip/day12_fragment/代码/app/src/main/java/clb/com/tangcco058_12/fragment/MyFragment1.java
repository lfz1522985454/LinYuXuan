package clb.com.tangcco058_12.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import clb.com.tangcco058_12.R;

/**
 * Created by cuilibao on 2017/9/1.
 */

public class MyFragment1 extends Fragment {
    View mView;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //getContext() 获取父容器的上下文
        mView = LayoutInflater.from(getContext()).inflate(R.layout.fragment01, container, false);
        return mView;
    }
}

package clb.com.tangcco058_12;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.widget.RadioGroup;

import clb.com.tangcco058_12.fragment.QQFragment;
import clb.com.tangcco058_12.fragment.QQKongjianFragment;

public class QQActivity extends AppCompatActivity {
    private QQFragment mQQFragment;
    private QQKongjianFragment mQQKongjianFragment;
    private RadioGroup mGroup;
    private FragmentManager mManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qq);
        mGroup = (RadioGroup) findViewById(R.id.mGroup);

        mQQFragment = new QQFragment();


        mManager = getSupportFragmentManager();

        FragmentTransaction ft = mManager.beginTransaction();
        ft.replace(R.id.container, mQQFragment);
        ft.commit();


        mGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_1:
                        //将qqfragment显示
                        //Intent intent = new Intent();
                        //从Activity向Fragment传值Bundle
                        Bundle bundle = new Bundle();
                        bundle.putString("key_qq", "qq页面");
                        mQQFragment.setArguments(bundle);

                        FragmentTransaction ft1 = mManager.beginTransaction();
                        ft1.replace(R.id.container, mQQFragment);
                        ft1.commit();
                        break;
                    case R.id.rb_2:
                        //空间
                        mQQKongjianFragment = new QQKongjianFragment();
                        Bundle bundle1 = new Bundle();
                        bundle1.putString("key_qq_kongjian", "qq空间页面");
                        mQQKongjianFragment.setArguments(bundle1);

                        //顺序 先传值 再替换
                        FragmentTransaction ft2 = mManager.beginTransaction();
                        ft2.replace(R.id.container, mQQKongjianFragment);
                        ft2.commit();
                        break;
                }
            }
        });
    }
}

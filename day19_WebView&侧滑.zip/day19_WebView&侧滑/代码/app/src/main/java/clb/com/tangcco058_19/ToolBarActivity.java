package clb.com.tangcco058_19;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

public class ToolBarActivity extends AppCompatActivity {
    private Toolbar mToolbar;

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tool_bar);


        mToolbar = (Toolbar) findViewById(R.id.mToolbar);

        initToolBar();
        initDrawer();

    }

    private void initDrawer() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.mDrawer);
        //设置三个杠
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,mToolbar,R.string.open,R.string.close);
        //三个杠
        mToggle.syncState();

        mDrawerLayout.addDrawerListener(mToggle);
    }

    private void initToolBar() {
        mToolbar.setTitle("标题");
        mToolbar.setLogo(R.mipmap.ic_launcher);
    }
}

package clb.com.tangcco058_19;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {
    boolean flag = true;
    private WebView mWebView;
    private Handler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWebView = (WebView) findViewById(R.id.mWebView);
        mHandler = new Handler();

        //添加网页
        //loadData()
        StringBuffer buffer = new StringBuffer();
        buffer.append("<html>");
        buffer.append("<head>");
        buffer.append("<meta charset='UTF-8'>");
        buffer.append("<title>");
        buffer.append("标题");
        buffer.append("</title>");
        buffer.append("</head>");
        buffer.append("<body>");
        buffer.append("<h1>");
        buffer.append("hello world");
        buffer.append("</h1>");
        buffer.append("</body>");
        buffer.append("</html>");


        //String  json  html
        //1:拼接  从网络获取的html
        //mWebView.loadData(buffer.toString(), "text/html;", "UTF-8");

        //2:从Assets目录中读取
        mWebView.loadUrl("file:///android_asset/demo1.html");

        //3:加载服务器的网页
//        mWebView.loadUrl("http://www.baidu.com");
//
        //获取设置对象
        WebSettings settings = mWebView.getSettings();

        //使Javascript可用
        settings.setJavaScriptEnabled(true);


        //怎么加载到客户端
        mWebView.setWebViewClient(new WebViewClient());


        //怎么才能按返回键 返回上一个页面


        //与js交互
        //1:方法:js中的方法

        //创建Handler
        //


        //别名
        mWebView.addJavascriptInterface(new MyDemo(),"demo");

    }

    /**
     * @param keyCode
     * @param event
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {
            //如果 网页有上一个页面 返回到上一个页面
            mWebView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void btn_change(View view) {
        //Handler.post
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (flag) {
                    //处理网页的方法
                    mWebView.loadUrl("javascript:wave()");

                } else {
                    mWebView.loadUrl("javascript:waveBack()");

                }
                flag = !flag;

            }
        });
    }



    //1:创建一个类
    class MyDemo {
        //h5调用的方法
        @JavascriptInterface
        public void callAndroid() {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("标题")
                    .setMessage("消息")
                    .show();
        }
    }
}

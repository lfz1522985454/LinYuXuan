package clb.com.tangcco058_08.homework;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import clb.com.tangcco058_08.R;

public class SPActivity extends AppCompatActivity {
    private EditText et_name, et_pwd;
    private SharedPreferences preferences;
    private TextView tv_info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp);
        et_name = (EditText) findViewById(R.id.et_name);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        tv_info = (TextView) findViewById(R.id.tv_info);

        //name:存到文件中的名字  MODE_PRIVATE只能被我们自己的程序 读写
        preferences = getSharedPreferences("login_info", MODE_PRIVATE);
    }

    public void login(View view) {
        //获取内容 存储
        String name = et_name.getText().toString();
        if (name.length() == 0) {
            Toast.makeText(this, "请输入用户名", Toast.LENGTH_SHORT).show();
            return;
        }
        String pwd = et_pwd.getText().toString();
        if (pwd.length() == 0) {
            Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
            return;
        }
        //存储 .edit
        SharedPreferences.Editor edit = preferences.edit();
        edit.putString("name", name);
        edit.putString("pwd", pwd);

        //提交
        edit.commit();
        Toast.makeText(this, "存储成功", Toast.LENGTH_SHORT).show();
        //data/data/包名/sp/.xml   root xml

    }

    public void getLogin(View view) {
        //获取存储的信息
        String name = preferences.getString("name", "无名氏");
        String pwd = preferences.getString("pwd", "***");
        tv_info.setText(name + "\n" + pwd);

    }
}

package clb.com.tangcco058_08.homework;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_08.R;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    private Gallery mGallery;
    private List<String> mData = new ArrayList<>();

    private Integer[] imgs = {
            R.mipmap.a1,
            R.mipmap.a2,
            R.mipmap.a3,
            R.mipmap.a4,
            R.mipmap.a5,
            R.mipmap.a6,
            R.mipmap.a7,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView = (ListView) findViewById(R.id.mListView);

        for (int i = 0; i < 20; i++) {
            mData.add("我有" + i + "个老婆");

        }

        mListView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mData));

        View view = LayoutInflater.from(this).inflate(R.layout.head_gallery, null);
        //Gallery
        mGallery = (Gallery) view.findViewById(R.id.mGallery);

        mGallery.setAdapter(new MyAdapter());//ImageView


        mListView.addHeaderView(view);
    }

    class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return imgs.length;
        }

        @Override
        public Object getItem(int position) {
            return imgs[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
                convertView = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_gallery, parent, false);
                imageView = (ImageView) convertView.findViewById(R.id.item_img);
                convertView.setTag(imageView);
            } else {
                imageView = (ImageView) convertView.getTag();
            }

            imageView.setImageResource(imgs[position]);

            return convertView;
        }
    }

}

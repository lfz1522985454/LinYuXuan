package clb.com.tangcco058_08.homework;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

import clb.com.tangcco058_08.R;

public class WelConmeActivity extends AppCompatActivity {
    //延时
    //Handler
    Timer timer;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wel_conme);
        sharedPreferences = getSharedPreferences("login_info", MODE_PRIVATE);
        //嘚瑟几秒
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //判断sp里面是否存在用户信息
                String name = sharedPreferences.getString("name", "xx");
                String pwd = sharedPreferences.getString("pwd", "xx");
                if (name.length() == 0) {
                    //跳转登录
                    finish();
                } else {

                    //跳转主页
                    finish();

                }

            }
        }, 4000);

    }
}

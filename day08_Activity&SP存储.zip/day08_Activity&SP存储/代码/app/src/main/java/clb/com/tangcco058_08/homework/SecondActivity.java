package clb.com.tangcco058_08.homework;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import clb.com.tangcco058_08.R;

public class SecondActivity extends AppCompatActivity {
    private static final String TAG = "TAG";
    private TextView tv_result;


    /**
     * 初始化的时候 调用
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tv_result = (TextView) findViewById(R.id.tv_result);
        Log.d(TAG, "onCreate: SecondActivity");
        Intent intent = getIntent();
        Person person = (Person) intent.getSerializableExtra("person");

        tv_result.setText(person.getName() + "\n" + person.getAge());

    }

    /**
     * 开始
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: SecondActivity");
    }

    /**
     * 继续
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: SecondActivity");

    }

    /**
     * 暂停
     */
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: SecondActivity");
    }

    /**
     * 停止
     */
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: SecondActivity");
    }

    /**
     * 销毁
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: SecondActivity");
    }
}

package clb.com.tangcco058_08.homework;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import clb.com.tangcco058_08.R;

public class ThirdActivity extends AppCompatActivity implements View.OnClickListener {
    private Button button1,button2, button3;
    private String result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        button1 = (Button) findViewById(R.id.btn_1);
        button2 = (Button) findViewById(R.id.btn_2);
        button3 = (Button) findViewById(R.id.btn_3);


        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_1:
                result = ((Button) v).getText().toString();
                break;
            case R.id.btn_2:
                result = ((Button) v).getText().toString();
                break;
            case R.id.btn_3:
                result = ((Button) v).getText().toString();
                break;

        }

        //回传值  result
        Intent intent = new Intent();
        intent.putExtra("data", result);
        setResult(RESULT_OK, intent);

        //×跳转
        //关闭
        finish();

    }
}

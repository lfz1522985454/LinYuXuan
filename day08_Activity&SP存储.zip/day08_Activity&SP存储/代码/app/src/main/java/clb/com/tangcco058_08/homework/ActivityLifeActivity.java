package clb.com.tangcco058_08.homework;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import clb.com.tangcco058_08.R;

public class ActivityLifeActivity extends AppCompatActivity {
    private static final String TAG = "TAG";
    private TextView tv_result;

    /**
     * 初始化的时候 调用
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life);
        tv_result = (TextView) findViewById(R.id.tv_result);
        Log.d(TAG, "onCreate: ");
    }

    /**
     * 开始
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: ");
    }

    /**
     * 继续
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: ");

    }

    /**
     * 保存突发事件的数据
     *
     * @param outState           保存数据
     * @param outPersistentState
     */
    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putString("", "fds");
    }

    /**
     * 恢复数据
     *
     * @param savedInstanceState
     */
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        savedInstanceState.get("");
    }

    /**
     * 暂停
     */
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: ");
    }

    /**
     * 停止
     */
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: ");
    }

    /**
     * 销毁
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: ");
    }

    public void submit(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        //怎么传对象
        //序列化 :
        Person person = new Person("zhangsan", 10);
        intent.putExtra("person", person);
        startActivity(intent);

    }

    public void getXiaoQu(View view) {

        //Activity回传值
        Intent intent = new Intent(this, ThirdActivity.class);

        //startActivity(intent);
        //1:获取回传值的方法
        startActivityForResult(intent, 1);

    }
    //2:


    /**
     * @param requestCode 请求码
     * @param resultCode  返回码
     * @param data        返回的数据
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String result;
        if (requestCode == 1 && resultCode == RESULT_OK) {
            result = data.getStringExtra("data");
            tv_result.setText(result);
        }

    }
}

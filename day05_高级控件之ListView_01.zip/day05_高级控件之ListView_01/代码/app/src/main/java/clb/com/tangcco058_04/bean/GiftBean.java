package clb.com.tangcco058_04.bean;

/**
 * Created by cuilibao on 2017/8/16.
 */

public class GiftBean {
    private String name;
    private String info;
    private int img;

    public GiftBean() {

    }

    public GiftBean(String name, String info, int img) {
        this.name = name;
        this.info = info;
        this.img = img;
    }

    //alt+insert
    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

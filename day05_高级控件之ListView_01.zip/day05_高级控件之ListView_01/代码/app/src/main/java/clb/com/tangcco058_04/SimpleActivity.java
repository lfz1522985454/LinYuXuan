package clb.com.tangcco058_04;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SimpleActivity extends Activity {//AppCompatActivity 5.0出来的

    private ListView mListView;
    private List<Map<String, Object>> mData = new ArrayList<Map<String, Object>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple);
        mListView = (ListView) findViewById(R.id.mListView);
        //List<? extends Map<>>
        //数据源
        addData();
        //适配器
        //ArrayAdapter
        SimpleAdapter adapter = new SimpleAdapter(
                this,//上下文对象
                mData,//数据源
                R.layout.simple_item,//每个条目的布局
                new String[]{"key_text", "key_img"},//从哪来 key
                new int[]{R.id.item_text, R.id.item_img}//到哪去 id
        );

        mListView.setAdapter(adapter);

    }

    private void addData() {
        //图片  文字
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("key_text", "高兴");
        map.put("key_img", R.mipmap.weixiao);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "大笑");
        map.put("key_img", R.mipmap.daxiao);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "愤怒");
        map.put("key_img", R.mipmap.fennu);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "伤心");
        map.put("key_img", R.mipmap.shangxin);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "调皮");
        map.put("key_img", R.mipmap.tiaopi);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "耍酷");
        map.put("key_img", R.mipmap.shuaku);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "大笑");
        map.put("key_img", R.mipmap.daxiao);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "愤怒");
        map.put("key_img", R.mipmap.fennu);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "伤心");
        map.put("key_img", R.mipmap.shangxin);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "调皮");
        map.put("key_img", R.mipmap.tiaopi);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "耍酷");
        map.put("key_img", R.mipmap.shuaku);
        mData.add(map);


        map = new HashMap<String, Object>();
        map.put("key_text", "大笑");
        map.put("key_img", R.mipmap.daxiao);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "愤怒");
        map.put("key_img", R.mipmap.fennu);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "伤心");
        map.put("key_img", R.mipmap.shangxin);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "调皮");
        map.put("key_img", R.mipmap.tiaopi);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "耍酷");
        map.put("key_img", R.mipmap.shuaku);
        mData.add(map);


        map = new HashMap<String, Object>();
        map.put("key_text", "大笑");
        map.put("key_img", R.mipmap.daxiao);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "愤怒");
        map.put("key_img", R.mipmap.fennu);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "伤心");
        map.put("key_img", R.mipmap.shangxin);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "调皮");
        map.put("key_img", R.mipmap.tiaopi);
        mData.add(map);

        map = new HashMap<String, Object>();
        map.put("key_text", "耍酷");
        map.put("key_img", R.mipmap.shuaku);
        mData.add(map);


    }
}

package clb.com.tangcco058_04;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    private List<String> result = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addData();

        //1:
        mListView = (ListView) findViewById(R.id.mListView);
        //2:神秘的东西  将数据 展示到ListView上
        //  适配器-->
        //泛型参数 SimpleAdapter  ArrayAdapter最简单  BaseAdapter最复杂
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(

                this,//上下文对象
                //R.layout.item,//关联每一个条目的布局 TextView
                android.R.layout.simple_expandable_list_item_2,
                result//集合或者数组
        );
        //3:展示
        mListView.setAdapter(adapter);
    }

    private void addData() {
        for (int i = 0; i < 100; i++) {
            result.add("我有" + i + "个老婆");
        }
    }
}

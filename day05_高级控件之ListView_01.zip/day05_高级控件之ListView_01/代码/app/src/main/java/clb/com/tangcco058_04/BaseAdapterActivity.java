package clb.com.tangcco058_04;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_04.bean.GiftBean;

public class BaseAdapterActivity extends Activity {
    private ListView mListView;
    private List<GiftBean> giftList = new ArrayList<>();
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_adapter);
        mListView = (ListView) findViewById(R.id.mListView);
        //button = (Button) findViewById(R.id.item_btn);

        //1:数据源
        addData();

        //2:适配器
        //ArrayAdapter
        //SimpleAdapter
        //BaseAdapter
        //1:类 继承 BaseAdapter
        //2:重写方法

        MyAdapter myAdapter = new MyAdapter();

        //3:展示
        mListView.setAdapter(myAdapter);


//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(BaseAdapterActivity.this, "点击了按钮", Toast.LENGTH_SHORT).show();
//            }
//        });

    }

    private void addData() {//网络获取  json  后台 servlet
        //图片 标题 描述 按钮
        GiftBean giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

        giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

        giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

        giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

        giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

        giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

        giftBean = new GiftBean("布娃娃", "这是一个布娃娃", R.mipmap.tiaopi);
        giftList.add(giftBean);

    }

    class MyAdapter extends BaseAdapter {

        /**
         * 数据源的数量
         *
         * @return
         */
        @Override
        public int getCount() {
            return giftList.size();
        }

        /**
         * item:条目 获取每一个List的条目
         *
         * @param position 位置
         * @return
         */
        @Override
        public GiftBean getItem(int position) {//返回当前位置对应的实体类
            return giftList.get(position);
        }

        /**
         * 返回位置
         *
         * @param position
         * @return
         */
        @Override
        public long getItemId(int position) {
            return position;
        }

        /**
         * @param position    位置
         * @param convertView 找到每一个条目的布局-->View类型 R.layout.
         * @param parent      打酱油 Activity
         * @return
         */
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            //SimpleAdapter(布局 和 数据源 )


            //1:将布局 转化成View
            //布局转化器 布局填充器
            convertView = LayoutInflater.from(BaseAdapterActivity.this).
                    inflate(R.layout.base_item, parent, false);

            //2:找到每一个控件
            ImageView imageView = (ImageView) convertView.findViewById(R.id.iv_head);
            TextView tv_title = (TextView) convertView.findViewById(R.id.tv_title);
            TextView tv_info = (TextView) convertView.findViewById(R.id.tv_info);
            Button button = (Button) convertView.findViewById(R.id.item_btn);

            //找到当前每一个条目的额实体类
            GiftBean giftBean = giftList.get(position);
            //设置到ImageView上
            imageView.setImageResource(giftBean.getImg());
            tv_title.setText(giftBean.getName());
            tv_info.setText(giftBean.getInfo());


            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(BaseAdapterActivity.this, "按钮" + position, Toast.LENGTH_SHORT).show();
                }
            });

            //返回
            return convertView;
        }
    }


}

package clb.com.tangcco058_03;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements  View.OnClickListener {
private EditText name,pwd;
    private Button pre,xia;
    private ImageView img;
    private int   [] image={R.mipmap.b1,R.mipmap.e1,R.mipmap.h1,R.mipmap.i1};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name= (EditText) findViewById(R.id.name);
        pwd= (EditText) findViewById(R.id.pwd);
        pre = (Button) findViewById(R.id.pre);
        xia= (Button) findViewById(R.id.xia);
        img= (ImageView) findViewById(R.id.img);
        pre.setOnClickListener(this);
        xia.setOnClickListener(this);
    }

    public void sub(View view) {

        //提交
        String name1=name.getText().toString();
        String pwd1=pwd.getText().toString();
        if(name1.length()==0||pwd1.length()==0){
            Toast.makeText(this, "用户名或者密码不允许为空", Toast.LENGTH_SHORT).show();
            return;
        }



        Toast.makeText(this, "登录成功", Toast.LENGTH_SHORT).show();

        Intent intent=new Intent(this,test_02.class);

        intent.putExtra("name",name1);
        intent.putExtra("pwd",pwd1);
        startActivity(intent);





    }
    int i=0;
    public   void onClick(View v){
        switch (v.getId()){
            case R.id.pre:
                i--;
                if(i<0){
                    i=image.length-1;

                }
                img.setImageResource(image[i]);



                break;
            case R.id.xia:
                i++;
                if(i>image.length-1){
                    i=0;

                }
                img.setImageResource(image[i]);
                break;

        }


    }
}

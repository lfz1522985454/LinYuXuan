package clb.com.tangcco058_03;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by cuilibao on 2017/8/14.
 */

public class test_02  extends AppCompatActivity {
    private TextView text;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_02);
        text= (TextView) findViewById(R.id.text);
        Intent intent=getIntent();
        String name=  intent.getStringExtra("name");
        String pwd=  intent.getStringExtra("pwd");

        text.setText("用户名:"+name+"密码:"+pwd);



    }
}

package clb.com.radiodemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Toast;

public class CheckActivity extends AppCompatActivity {
    //1:找到控件
    private LinearLayout linearLayout;
    private CheckBox mCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_layout);
        linearLayout = (LinearLayout) findViewById(R.id.linear);

        mCheckBox = (CheckBox) findViewById(R.id.check_all);

        //mCheckBox
        mCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            /**
             *
             * @param buttonView
             * @param isChecked   全选的选中状态
             */
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //全选
                for (int i = 0; i < linearLayout.getChildCount(); i++) {
                    CheckBox checkBox = (CheckBox) linearLayout.getChildAt(i);
                    checkBox.setChecked(isChecked);
                }
            }
        });

    }

    public void submit(View view) {
        //获取多选的选择事件
        //linearLayout 孩子的个数  linearLayout.children
        //linearLayout.getChildCount() 获取孩子的个数
        for (int i = 0; i < linearLayout.getChildCount(); i++) {
            //linearLayout.getChildAt(第几个孩子)
            CheckBox checkBox = (CheckBox) linearLayout.getChildAt(i);
            //当前的CheckBox是否被选中
            boolean checked = checkBox.isChecked();
            if (checked) {
                Toast.makeText(this, checkBox.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}

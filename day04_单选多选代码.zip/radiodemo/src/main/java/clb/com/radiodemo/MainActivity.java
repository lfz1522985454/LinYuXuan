package clb.com.radiodemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private RadioGroup mGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mGroup = (RadioGroup) findViewById(R.id.mGroup);

        mGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            /**
             *
             * @param group
             * @param checkedId  选择哪一个单选按钮
             */
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                switch (checkedId) {
//                    case R.id.rb_1:
//                        Toast.makeText(MainActivity.this, "你好 帅锅~", Toast.LENGTH_SHORT).show();
//                        break;
//                    case R.id.rb_2:
//                        Toast.makeText(MainActivity.this, "你好 镁铝~", Toast.LENGTH_SHORT).show();
//                        break;
//
//                    case R.id.rb_3:
//                        Toast.makeText(MainActivity.this, "我不认识你!滚~~", Toast.LENGTH_SHORT).show();
//                        break;
//                }

                if (R.id.rb_3 == checkedId) {

                }
                //Toast.makeText(MainActivity.this, "点了我", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void submit(View view) {
        //获取选中的单选按钮的id
        int checkedRadioButtonId = mGroup.getCheckedRadioButtonId();
        //判断
        //通过id获取控件
        RadioButton radioButton = (RadioButton) findViewById(checkedRadioButtonId);
        String result = radioButton.getText().toString();
        Toast.makeText(this, "你选择的是:" + result, Toast.LENGTH_SHORT).show();
    }
}

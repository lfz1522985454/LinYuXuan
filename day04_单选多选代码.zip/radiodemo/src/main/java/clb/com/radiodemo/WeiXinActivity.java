package clb.com.radiodemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.Toast;

public class WeiXinActivity extends AppCompatActivity {
    private RadioGroup mGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wei_xin);
        mGroup = (RadioGroup) findViewById(R.id.mGroup);
        mGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_message:
                        Toast.makeText(WeiXinActivity.this, "消息", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }
}

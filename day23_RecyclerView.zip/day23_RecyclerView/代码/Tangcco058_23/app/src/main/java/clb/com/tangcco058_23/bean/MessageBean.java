package clb.com.tangcco058_23.bean;

/**
 * Created by cuilibao on 2017/9/28.
 */

public class MessageBean {
    private String msg;
    private int type;//1 2 3
    private String time;

    public MessageBean() {
    }

    public MessageBean(String msg, int type) {
        this.msg = msg;
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMsg() {
        return msg;
    }

    public int getType() {
        return type;
    }
}

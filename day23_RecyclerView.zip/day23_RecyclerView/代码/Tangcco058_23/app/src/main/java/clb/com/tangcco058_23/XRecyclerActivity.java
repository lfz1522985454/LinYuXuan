package clb.com.tangcco058_23;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.view.View;
import android.widget.Toast;

import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_23.adapter.MyAdapter;

public class XRecyclerActivity extends AppCompatActivity {
    private XRecyclerView mXRecyclerView;
    private List<String> mData = new ArrayList<>();
    private MyAdapter mAdapter;
    private Handler mHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
        mXRecyclerView = (XRecyclerView) findViewById(R.id.mXRecyclerView);
        mHandler = new Handler();
        //默认  ListView
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mXRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));

        mXRecyclerView.setRefreshProgressStyle(ProgressStyle.LineScaleParty);
        mXRecyclerView.setArrowImageView(R.drawable.loading_01);

        mXRecyclerView.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //重新加载数据
                        //停止刷新
                        mXRecyclerView.refreshComplete();
                    }
                }, 2000);
            }

            @Override
            public void onLoadMore() {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mXRecyclerView.setNoMore(false);
                    }
                }, 2000);
            }
        });


        //数据源
        addData();

        //适配器 不再是 BaseAdapter
        //v7 Adapter
        mAdapter = new MyAdapter(this, mData);
        mXRecyclerView.setAdapter(mAdapter);

//        mRecyclerView.

        mAdapter.setItemClickListener(new MyAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View itemView, int position) {
                Toast.makeText(XRecyclerActivity.this, "单击了:"+position, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onItemLongClick(View itemView, int position) {
                Toast.makeText(XRecyclerActivity.this, "长按了:"+position, Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void addData() {
        for (int i = 'A'; i < 'z'; i++) {
            mData.add(String.valueOf((char) i));
        }
    }

}

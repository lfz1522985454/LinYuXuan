package clb.com.tangcco058_23.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import clb.com.tangcco058_23.R;

/**
 * Created by cuilibao on 2017/9/28.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {
    private List<String> mData;
    private Context mContext;
    //2:初始化
    private ItemClickListener mItemClickListener;

    public MyAdapter(Context context, List<String> data) {
        mContext = context;
        mData = data;
    }

    /**
     * 创建 控件
     *
     * @param parent
     * @param viewType
     * @return
     */
    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item, parent, false);
//        View view = LayoutInflater.from(mContext).inflate(R.layout.item1, parent, false);
        //不能在此设置点击事件
        //view.setOnClickListener();//position

        return new MyHolder(view);
    }

    /**
     * 绑定的方法
     *
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(final MyHolder holder, final int position) {
        holder.tv_item.setText(mData.get(position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //position
                //广播 接口回调
                mItemClickListener.onItemClick(holder.itemView, position);
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mItemClickListener.onItemLongClick(holder.itemView, position);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    //3:赋值
    public void setItemClickListener(ItemClickListener itemClickListener) {
        mItemClickListener = itemClickListener;
    }

    //1:
    public interface ItemClickListener {
        //几个方法???
        //单击
        void onItemClick(View itemView, int position);

        //长按
        void onItemLongClick(View itemView, int position);
    }

    class MyHolder extends RecyclerView.ViewHolder {
        TextView tv_item;

        /**
         * @param itemView 创建布局的时候 关联的View
         */
        public MyHolder(View itemView) {
            super(itemView);
            tv_item = (TextView) itemView.findViewById(R.id.tv_item);
        }
    }

}

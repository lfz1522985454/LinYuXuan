package clb.com.tangcco058_23;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_23.bean.MessageBean;

public class DiffActivity extends AppCompatActivity {
    List<MessageBean> mBeanList = new ArrayList<>();
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diff);
        mListView = (ListView) findViewById(R.id.mListView);
        //1:一个条目 显示 或者隐藏
        //2:两个回调方法

        //网络
        //模拟
        addData();

        MyAdapter myAdapter = new MyAdapter();

        mListView.setAdapter(myAdapter);
    }

    private void addData() {
        MessageBean messageBean = new MessageBean("在么?", 1);
        mBeanList.add(messageBean);

        messageBean = new MessageBean();
        messageBean.setTime("2017-07-09");
        messageBean.setType(3);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("在", 2);
        mBeanList.add(messageBean);

        messageBean = new MessageBean();
        messageBean.setTime("2017-07-09");
        messageBean.setType(3);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("有钱么? 帮我充点话费", 1);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("你说什么?", 2);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("帮我充点话费", 1);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("不是这句 上一句", 2);
        mBeanList.add(messageBean);

        messageBean = new MessageBean();
        messageBean.setTime("2017-07-09");
        messageBean.setType(3);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("在么?", 1);
        mBeanList.add(messageBean);

        messageBean = new MessageBean("不在", 2);
        mBeanList.add(messageBean);
    }

    class MyAdapter extends BaseAdapter {

        private int mItemViewType;

        @Override
        public int getCount() {
            return mBeanList.size();
        }

        @Override
        public MessageBean getItem(int position) {
            return mBeanList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        /**
         * @param position
         * @param convertView
         * @param parent
         * @return
         */

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder1 viewHolder1 = null;
            ViewHolder2 viewHolder2 = null;
            ViewHolder3 viewHolder3 = null;
            mItemViewType = getItemViewType(position);
            if (convertView == null) {

                switch (mItemViewType) {
                    case 1:
                        viewHolder1 = new ViewHolder1();
                        convertView = LayoutInflater.from(DiffActivity.this).inflate(R.layout.item01, parent, false);
                        viewHolder1.tv_item01 = (TextView) convertView.findViewById(R.id.tv_item1);
                        convertView.setTag(viewHolder1);

                        break;
                    case 2:
                        viewHolder2 = new ViewHolder2();
                        convertView = LayoutInflater.from(DiffActivity.this).inflate(R.layout.item02, parent, false);
                        viewHolder2.tv_item02 = (TextView) convertView.findViewById(R.id.tv_item2);
                        convertView.setTag(viewHolder2);

                        break;
                    case 3:
                        viewHolder3 = new ViewHolder3();
                        convertView = LayoutInflater.from(DiffActivity.this).inflate(R.layout.item03, parent, false);
                        viewHolder3.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
                        convertView.setTag(viewHolder3);

                        break;

                }

            } else {
                switch (mItemViewType) {
                    case 1:
                        viewHolder1 = (ViewHolder1) convertView.getTag();
                        break;
                    case 2:
                        viewHolder2 = (ViewHolder2) convertView.getTag();

                        break;
                    case 3:
                        viewHolder3 = (ViewHolder3) convertView.getTag();

                        break;
                }
            }

            //赋值
            switch (mItemViewType) {
                case 1:
                    viewHolder1.tv_item01.setText(getItem(position).getMsg());
                    break;
                case 2:
                    viewHolder2.tv_item02.setText(getItem(position).getMsg());

                    break;
                case 3:
                    viewHolder3.tv_time.setText(getItem(position).getTime());

                    break;

            }

            return convertView;
        }

        /**
         * @param position
         * @return 当前的视图类型 1 2 3
         */
        @Override
        public int getItemViewType(int position) {
            return mBeanList.get(position).getType();
        }

        /**
         * 类型的总数量
         *
         * @return
         */
        @Override
        public int getViewTypeCount() {
            return 3;
        }

        class ViewHolder1 {
            TextView tv_item01;
        }

        class ViewHolder2 {
            TextView tv_item02;

        }

        class ViewHolder3 {
            TextView tv_time;

        }
    }

    //1:


}

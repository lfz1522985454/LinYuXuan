package clb.com.tangcco058_10;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by cuilibao on 2017/8/28.
 */

public class SDUtils {

    /**
     * filePath:文件的相对路径 abcd.png
     *
     * @author clb
     * create at 2017/8/28
     */
    public static byte[] getFileFromSD(Context context, String filePath) {
        //流
        //1:找到路径  Environment 环境 getExternalStorage 获取SD卡 Directory目录  getAbsolutePath()绝对路径
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + filePath;
//        Toast.makeText(this, path, Toast.LENGTH_SHORT).show();

        //File---> 流
        File file = new File(path);
        //缓冲
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        FileInputStream fis = null;
        try {
            //判断文件是否存在
            if (file.exists()) {
                Toast.makeText(context, "文件存在", Toast.LENGTH_SHORT).show();


                fis = new FileInputStream(file);
                //byte[]:每次读取多少
                byte[] bytes = new byte[1024];

                //存放每次的内容
                int len = 0;
                while ((len = fis.read(bytes)) != -1) {
                    baos.write(bytes, 0, len);
                }
                byte[] data = baos.toByteArray();
                return data;


            } else {
                Toast.makeText(context, "文件不存在", Toast.LENGTH_SHORT).show();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (baos != null) {
                try {
                    baos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }


    /**
     * 写数据到SD卡
     *
     * @param data     写的内容
     * @param dir      父路径  "../0"+"tcmp052"
     * @param fileName 写的文件的名字
     * @return 是否写入成功
     */
    public static boolean writeToSD(byte[] data, String dir, String fileName) {
        //什么流 输出流
        //File.separator
        //父路径
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + dir;
        File file = new File(path);

        if (!file.exists()) {
            //创建一个路径
            file.mkdir();
        }
        //创建一个文件
//            file.createNewFile();

        //写
        try {
            FileOutputStream fos = new FileOutputStream(new File(file, fileName));

            //写文件
            fos.write(data);
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;

    }


}

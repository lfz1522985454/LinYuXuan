package clb.com.tangcco058_10;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    private ImageView mImage;
    private TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mImage = (ImageView) findViewById(R.id.mImage);
        tv_result = (TextView) findViewById(R.id.tv_result);
    }

    public void getAssetsFile(View view) {
        //从assets中读取图片
        try {
            //获取流文件
            InputStream inputStream = getAssets().open("a2.jpg");
            //转化成图片

            //Bitmap 位图
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            mImage.setImageBitmap(bitmap);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//
//    public void getAssetsText(View view) {
//        try {
//            //缓冲流:将每次读取的结果放到缓冲里面
//            ByteArrayOutputStream baos = new ByteArrayOutputStream();
//            //字节流
//            InputStream inputStream = getAssets().open("test.txt");
//            //文本
//            //字节流-->字符流
//            //二进制  每次读取的长度
//            byte[] bytes = new byte[1024];
//
//            //接收每次读取的结果
//            int len = 0;
//            //循环  != -1还没有读完
//            while ((len = inputStream.read(bytes)) != -1) {  //10101001000101011  -1
//
//                //len--->byte[]-->String
//
//                //将len 存到缓冲里面
//                baos.write(bytes, 0, len);
//            }
//
//            //byte[]
//            byte[] data = baos.toByteArray();
//
//            //结果
//            String result = new String(data);
//
//            tv_result.setText(result);
//
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//    }

    public void getAssetsText(View view) {
        try {
            //字节流
            InputStream inputStream = getAssets().open("test.txt");

            //包装流    InputStreamReader 转化流--->字符流
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            //每一行
            String line = "";
            //汇总
            StringBuilder buffer = new StringBuilder();//线程不安全
            //StringBuilder builder = new StringBuilder(); //线程安全
            //reader.readLine() 读取一行  = null说明走到头了
            while ((line = reader.readLine()) != null) {
                buffer.append(line).append("\n");
            }
            String result = buffer.toString();
            tv_result.setText(result);


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void getSDFile(View view) {
//        //流
//        //1:找到路径  Environment 环境 getExternalStorage 获取SD卡 Directory目录  getAbsolutePath()绝对路径
//        String path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/abcd.png";
////        Toast.makeText(this, path, Toast.LENGTH_SHORT).show();
//
//        //File---> 流
//        File file = new File(path);
//        //判断文件是否存在
//        if (file.exists()) {
//            Toast.makeText(this, "文件存在", Toast.LENGTH_SHORT).show();
//
//            try {
//                FileInputStream fis = new FileInputStream(file);
//                //--byte[]
//                //流
//                Bitmap bitmap = BitmapFactory.decodeStream(fis);
//                mImage.setImageBitmap(bitmap);
//
//            } catch (FileNotFoundException e) {
//                e.printStackTrace();
//            }
//
//        } else {
//            Toast.makeText(this, "文件不存在", Toast.LENGTH_SHORT).show();
//        }


        //2:FileInputStream
        //流-->Bitmap


//        byte[] data = SDUtils.getFileFromSD(this, "tcmp042/b1.png");
//        //图片
//        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
//        mImage.setImageBitmap(bitmap);

        byte[] data = SDUtils.getFileFromSD(this, "0032/json.json");
        tv_result.setText(new String(data));


    }

    public void setSDFile(View view) {

        try {
            //获取流文件
            InputStream inputStream = getAssets().open("a2.jpg");
            //转化成图片

            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            byte[] bytes = new byte[1024];
            int len = 0;
            while ((len = inputStream.read(bytes)) != -1) {
                baos.write(bytes, 0, len);
            }


            boolean isSave = SDUtils.writeToSD(baos.toByteArray(), "tcmp058", "a3.jpg");
            if (isSave) {
                Toast.makeText(this, "存储成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "存储失败", Toast.LENGTH_SHORT).show();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package clb.com.tangcco058_13;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import clb.com.tangcco058_13.fragment.ShowFragment;
import clb.com.tangcco058_13.fragment.ValueFragment;

//5:实现接口 重写方法
public class MainActivity extends AppCompatActivity implements ValueFragment.IparseValue{
//    private TextView tv_result;
    private ValueFragment mValueFragment;
    private ShowFragment mShowFragment;
    private FragmentManager mManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        tv_result = (TextView) findViewById(tv_result);

        mValueFragment = new ValueFragment();

        mManager = getSupportFragmentManager();
        FragmentTransaction ft = mManager.beginTransaction();
        ft.replace(R.id.container, mValueFragment);
        ft.commit();

    }

    @Override
    public void getData(String result) {
//        tv_result.setText(result);

        mShowFragment = new ShowFragment();
        Bundle bundle = new Bundle();
        bundle.putString("key", result);
        mShowFragment.setArguments(bundle);
        FragmentTransaction ft = mManager.beginTransaction();
        ft.replace(R.id.container2, mShowFragment);

        ft.commit();
    }
}

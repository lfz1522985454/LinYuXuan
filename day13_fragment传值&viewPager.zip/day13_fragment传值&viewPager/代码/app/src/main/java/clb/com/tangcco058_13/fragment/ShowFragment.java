package clb.com.tangcco058_13.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import clb.com.tangcco058_13.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ShowFragment extends Fragment {


    private View mView;
    private TextView tv_show;



    public ShowFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = LayoutInflater.from(getContext()).inflate(R.layout.layout_show_fragment, container, false);
        tv_show = (TextView) mView.findViewById(R.id.tv_show);
        Bundle bundle = getArguments();
        if (bundle != null) {
            String result = bundle.getString("key");
            tv_show.setText(result);
        }
        return mView;
    }
    //3.2:赋值


}

package clb.com.tangcco058_13;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewPagerActivity extends AppCompatActivity {
    private ViewPager mViewPager;
    private List<Integer> images = new ArrayList<>();//资源文件-->ImageView
    private List<ImageView> mImageViews = new ArrayList<>();
    private String[] titles = {"首页1", "首页2", "首页3", "首页4", "首页5", "首页6", "首页7"};
    private LinearLayout dot_linear;

    private List<ImageView> dot_imgs = new ArrayList<>();





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_pager);
        mViewPager = (ViewPager) findViewById(R.id.mViewPager);
        dot_linear = (LinearLayout) findViewById(R.id.dot_linear);


        //数据源
        addData();

        //适配器

        addDot();

    }

    /**
     * 初始化小圆点
     */
    private void addDot() {
        for (int i = 0; i < images.size(); i++) {
            //初始化小圆点 将小圆点添加到 LinearLayout里面
            ImageView imageView = new ImageView(this);
            ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(50, 50);
            imageView.setLayoutParams(params);

            imageView.setImageResource(R.mipmap.ic_launcher);


            //将位置 记录下来
            imageView.setTag(i);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //获取出来
                    int tag = (int) ((ImageView) v).getTag();
                    mViewPager.setCurrentItem(tag);//变成小圆点 选中的时候 变色
                }
            });

            dot_linear.addView(imageView);


        }
    }

    private void addData() {
        images.add(R.mipmap.a1);
        images.add(R.mipmap.a2);
        images.add(R.mipmap.a3);
        images.add(R.mipmap.a4);
        images.add(R.mipmap.a5);
        images.add(R.mipmap.a6);
        images.add(R.mipmap.a7);

        for (int i = 0; i < images.size(); i++) {
            //动态创建
            ImageView imageView = new ImageView(this);
            //创建宽高
            ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            //将宽高设置给ImageView
            imageView.setLayoutParams(params);
            imageView.setImageResource(images.get(i));

            //数据源
            mImageViews.add(imageView);

        }

        mViewPager.setAdapter(new MyAdapter());

        //设置跳转到第几个 ViewPager
        mViewPager.setCurrentItem(3);


        /**
         * 当页面改变的时候触发
         */
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            /**
             * 滑动结束之后 会回调
             * @param position
             */
            @Override
            public void onPageSelected(int position) {
//                Toast.makeText(ViewPagerActivity.this, ""+position, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPageScrollStateChanged(int state) {//0 1 2

            }
        });

    }

    class MyAdapter extends PagerAdapter {
        /**
         * 数量
         *
         * @return
         */
        @Override
        public int getCount() {
            return mImageViews.size();
        }

        /**
         * 判断当前视图是否为显示的视图
         *
         * @param view
         * @param object
         * @return
         */
        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        /**
         * 初始化
         *
         * @param container ViewPager
         * @param position  位置
         * @return
         */
        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            //添加到ViewPager中
            ImageView imageView = mImageViews.get(position);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(ViewPagerActivity.this, "" + position, Toast.LENGTH_SHORT).show();
                }
            });
            container.addView(imageView);
            return imageView;

        }

        /**
         * 销毁
         *
         * @param container ViewPager
         * @param position
         * @param object
         */
        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            //super.destroyItem(container, position, object);
            container.removeView(mImageViews.get(position));
        }

        /**
         * 标题
         * @param position
         * @return
         */
        @Override
        public CharSequence getPageTitle(int position) {
            return titles[position];
        }
    }

}

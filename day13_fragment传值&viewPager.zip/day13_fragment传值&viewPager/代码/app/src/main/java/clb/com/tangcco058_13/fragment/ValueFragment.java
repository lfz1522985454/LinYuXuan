package clb.com.tangcco058_13.fragment;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import clb.com.tangcco058_13.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ValueFragment extends Fragment {


    //3.1:赋值 接口对象
    IparseValue mIparseValue;
    private View mView;
    private EditText mEditText;
    private Button mButton;


    public ValueFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_value, container, false);
        mButton = (Button) mView.findViewById(R.id.btn_parseValue);
        mEditText = (EditText) mView.findViewById(R.id.fragment_et);


        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = mEditText.getText().toString().trim();
                if (result.equals("")) {
                    Toast.makeText(getContext(), "请输入内容", Toast.LENGTH_SHORT).show();
                    return;
                }
                //传到Activity中
                //4:回调方法
                mIparseValue.getData(result);
            }
        });
        return mView;
    }
    //3.2:赋值

    /**
     *
     * @param context Activity的上下文
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof IparseValue) {
            mIparseValue = (IparseValue) context;
        } else {
            throw new IllegalArgumentException("请实现接口");
        }
    }

    //1:定义一个接口
    public interface IparseValue {//impl

        //2:定义一个方法
        void getData(String result);

    }
}

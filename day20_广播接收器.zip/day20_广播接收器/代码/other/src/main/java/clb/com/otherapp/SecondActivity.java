package clb.com.otherapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    private TextView tv_other;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tv_other = (TextView) findViewById(R.id.tv_other);

        String hello = getIntent().getStringExtra("hello");
        tv_other.setText(hello);

    }
}

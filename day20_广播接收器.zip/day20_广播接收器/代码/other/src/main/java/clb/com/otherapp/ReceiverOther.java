package clb.com.otherapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;



/**
 * Created by cuilibao on 2017/9/20.
 */

public class ReceiverOther extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String hello = intent.getStringExtra("hello");

        //接收另一个应用程序发送过来的广播
        //Toast.makeText(context, "接收到了另一个进程发送过来的广播", Toast.LENGTH_SHORT).show();
        Intent intent1 = new Intent(context,SecondActivity.class);
        intent1.putExtra("hello", hello);
        //创建一个栈空间
        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent1);
    }
}

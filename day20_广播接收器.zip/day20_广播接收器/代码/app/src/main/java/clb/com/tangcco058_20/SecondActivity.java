package clb.com.tangcco058_20;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class SecondActivity extends AppCompatActivity {
    private ImageView imageView;
    private MyReceiver03 mMyReceiver03;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        imageView = (ImageView) findViewById(R.id.imageView);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mMyReceiver03 = new MyReceiver03();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("downLoad058");
        registerReceiver(mMyReceiver03, intentFilter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mMyReceiver03 != null) {
            unregisterReceiver(mMyReceiver03);

        }
    }

    public void downLoad(View view) {
        //下载图片
        new Thread(new Runnable() {
            @Override
            public void run() {
                //下载的操作
                try {
                    HttpURLConnection connection = (HttpURLConnection) new URL("http://file.zanmeishi.com/album/2017/09/19/59c07475694d2321dd3e17e2.jpg").openConnection();
                    connection.setRequestMethod("GET");

                    connection.setReadTimeout(5000);
                    connection.setConnectTimeout(5000);

                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        InputStream inputStream = connection.getInputStream();
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();

                        int len = 0;
                        byte[] bytes = new byte[1024];

                        while ((len = inputStream.read(bytes)) != -1) {
                            baos.write(bytes, 0, len);

                        }
                        byte[] data = baos.toByteArray();
                        //BitmapFactory.decodeByteArray(data, 0, data.length);
                        //Handler 异步任务 xUtils
                        //广播 线程之间的通信

                        Intent intent = new Intent();
                        intent.putExtra("tcmp", data);
                        intent.setAction("downLoad058");
                        sendBroadcast(intent);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
//                Intent intent = new Intent();
//                intent.putExtra("tcmp", "hello 我是子线程");
//                intent.setAction("downLoad058");
//                sendBroadcast(intent);
            }
        }).start();
    }

    public void sendOtherApp(View view) {
        //发送一个广播
        Intent intent = new Intent();
        intent.setAction("clb.com.otherapp.TCMP58");
        intent.putExtra("hello", "唯有套路得人心");
        sendBroadcast(intent);

    }

    class MyReceiver03 extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            byte[] tcmps = intent.getByteArrayExtra("tcmp");
            Bitmap bitmap = BitmapFactory.decodeByteArray(tcmps, 0, tcmps.length);
            imageView.setImageBitmap(bitmap);
//            String tcmp = intent.getStringExtra("tcmp");
//            Toast.makeText(context, tcmp, Toast.LENGTH_SHORT).show();
        }
    }

}

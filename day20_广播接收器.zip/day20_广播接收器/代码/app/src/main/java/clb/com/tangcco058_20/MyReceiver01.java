package clb.com.tangcco058_20;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * 接收方
 * Created by cuilibao on 2017/9/20.
 */

public class MyReceiver01 extends BroadcastReceiver{

    /**
     * 接收广播的方法
     * @param context 上下文对象
     * @param intent 传递过来的信息  intent 四大组件通信
     *               广播的生命周期 只有10s左右
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "静态注册 接收到了广播", Toast.LENGTH_SHORT).show();
//        new AlertDialog.Builder(context)
//                .setTitle("Title")
//                .setMessage("广播")
//                .show();
    }
}

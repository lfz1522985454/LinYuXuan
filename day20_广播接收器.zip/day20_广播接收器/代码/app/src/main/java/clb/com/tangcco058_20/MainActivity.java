package clb.com.tangcco058_20;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    MyReceiver02 mMyReceiver02;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMyReceiver02 = new MyReceiver02();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        //过滤那条广播
        intentFilter.addAction("tcmp058");
        //动态注册
        registerReceiver(mMyReceiver02, intentFilter);
    }


    /**
     * ...............
     **/
    @Override
    protected void onStop() {
        super.onStop();
        //取消注册
        if (mMyReceiver02 != null) {
            unregisterReceiver(mMyReceiver02);
        }
    }


    public void sendToReceiver(View view) {
        Intent intent = new Intent();
        //设置行为  fm 103.7..
        intent.setAction("tcmp058");
        sendBroadcast(intent);
    }
}

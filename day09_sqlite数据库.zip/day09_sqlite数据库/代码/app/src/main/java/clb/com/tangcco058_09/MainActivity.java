package clb.com.tangcco058_09;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import clb.com.tangcco058_09.bean.Person;
import clb.com.tangcco058_09.db.DBHelper;

public class MainActivity extends AppCompatActivity {
    private EditText et_name, et_age,et_id;
    private DBHelper dbHelper;
    private ListView mListView;
    private String result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_name = (EditText) findViewById(R.id.et_name);
        et_age = (EditText) findViewById(R.id.et_age);
        et_id = (EditText) findViewById(R.id.et_id);
        mListView = (ListView) findViewById(R.id.mListView);

        dbHelper = new DBHelper(this);
    }

    public void insertIntoDatabase(View view) {
        if (et_name.getText().length() == 0||et_age.getText().length()==0) {
            Toast.makeText(this, "请输入数据", Toast.LENGTH_SHORT).show();
            return;
        }
        String name = et_name.getText().toString();
        int age = Integer.parseInt(et_age.getText().toString());


        Person person = new Person(name, age);
        dbHelper.insertData(person);
        Toast.makeText(this, "插入成功", Toast.LENGTH_SHORT).show();
    }

    public void queryAll(View view) {
        Cursor cursor = dbHelper.queryAll();
        //适配器??
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.item,
                cursor,//数据源
                new String[]{"_id", "name", "age"},//
                new int[]{R.id.tv_id, R.id.tv_name, R.id.tv_age},
                CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER//观察者模式
        ){
            @Override
            public int getCount() {
                return super.getCount();
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return super.getView(position, convertView, parent);
            }
        };
        mListView.setAdapter(adapter);
    }

    public void deleteById(View view) {
        result = et_id.getText().toString();
        if (result.length() == 0) {
            Toast.makeText(this, "id", Toast.LENGTH_SHORT).show();
            return;
        }
        final int id = Integer.parseInt(result);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog, null);
        Button buttonSure = (Button) dialogView.findViewById(R.id.dialog_sure);
        Button buttonCancel = (Button) dialogView.findViewById(R.id.dialog_cancel);

        buttonSure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.deleteById(id);
                Toast.makeText(MainActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                queryAll(null);
                //builder.set
            }
        });
        builder.setView(dialogView);
        builder.show();


    }

    public void update(View view) {
        result = et_id.getText().toString();
        if (result.length() == 0) {
            Toast.makeText(this, "id", Toast.LENGTH_SHORT).show();
            return;
        }
        final int id = Integer.parseInt(result);
        if (et_name.getText().length() == 0||et_age.getText().length()==0) {
            Toast.makeText(this, "请输入数据", Toast.LENGTH_SHORT).show();
            return;
        }
        String name = et_name.getText().toString();
        int age = Integer.parseInt(et_age.getText().toString());



        Person person = new Person(id,name,age);
        dbHelper.updataById(person);
        queryAll(null);

    }
}

package clb.com.tangcco058_09.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import clb.com.tangcco058_09.bean.Person;

/**
 * Created by cuilibao on 2017/8/25.
 */

public class DBHelper extends SQLiteOpenHelper {
    private SQLiteDatabase db;
    private String TABLE_NAME = "person";

    /**
     * 1:创建数据库 如果此数据库存在 则 不会创建
     * .db
     *
     * @param context name:数据库的名称
     *                factory:工厂
     *                version 版本号
     */
    public DBHelper(Context context) {
        super(context, "user.db", null, 1);
        //初始化SqliteDatabase
        db = getReadableDatabase();//如果内存满了 就不写了
        //db = getWritableDatabase();//如果内存满了 继续写 写到崩溃为止
    }

    /**
     * 创建数据库表
     *
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        //执行一个sql语句 person表名
        String sql = "create table " + TABLE_NAME + "(" +
                "_id integer primary key," +
                "name text not null," +
                "age integer not null)";
        db.execSQL(sql);
    }

    /**
     * @param db
     * @param oldVersion 旧版本
     * @param newVersion 新版本
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /**
     * 添加数据
     */
    public void insertData(Person perosn) {
        //表名  如果列为空 要插入什么样的数据
        ContentValues values = new ContentValues();
        //map
        values.put("name", perosn.getName());//key:列明  value:数据
        values.put("age", perosn.getAge());//key:列明  value:数据
        db.insert(TABLE_NAME, null, values);

    }

    /**
     * 1:sql
     * 2:执行
     * 3:返回 :Cursor结果集  类似于List
     */
    public Cursor queryAll() {
        //1:表名  2:列名 String[] 3:条件 4:条件的替换 5:分组 6:having语句 7:排序
        return db.query(TABLE_NAME, null, null, null, null, null, null);
    }

    public void deleteById(int id) {
        db.delete(TABLE_NAME, "_id=?", new String[]{String.valueOf(id)});
    }

    public void updataById(Person person) {
        ContentValues values = new ContentValues();
        //values.put("_id");
        values.put("name", person.getName());
        values.put("age", person.getAge());
        db.update(TABLE_NAME, values, "_id=?", new String[]{String.valueOf(person.get_id())});

    }
}

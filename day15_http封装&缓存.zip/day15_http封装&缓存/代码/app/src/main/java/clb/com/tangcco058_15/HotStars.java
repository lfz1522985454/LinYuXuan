package clb.com.tangcco058_15;

/**
 * Created by cuilibao on 2017/9/8.
 */

public class HotStars {


    /**
     * sid : 3
     * name : 李钟硕
     * thumb : http://pic8.qiyipic.com/image/20160307/b3/5f/p_1037671_m_601_m3.jpg
     * baikeUrl : http://baike.baidu.com/link?url=_0M2NG17DFDCqsvF_Hw9Ljb_kRSWgF_1PHz76quSjtKoztOlwE7CxwgfeojYWxVV6SCIeORJ4KvF6ZfKI1qUta
     * fansCount : 898637
     * rank : 1
     */

    private String name;
    private String thumb;
    private String baikeUrl;
    private int fansCount;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }

    public String getBaikeUrl() {
        return baikeUrl;
    }

    public void setBaikeUrl(String baikeUrl) {
        this.baikeUrl = baikeUrl;
    }

    public int getFansCount() {
        return fansCount;
    }

    public void setFansCount(int fansCount) {
        this.fansCount = fansCount;
    }

}

package clb.com.tangcco058_15;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

/**
 * Created by cuilibao on 2017/9/8.
 */

public class ImageLoader {

    //
    private LruCache<String, Bitmap> mLruCache;

    public ImageLoader() {
        //获取最大内存
        long maxMemory = Runtime.getRuntime().maxMemory();
        int runtime = (int) (maxMemory / 3);
        mLruCache = new LruCache<String, Bitmap>(runtime){
            /**
             * 返回当前图片的打小
             * @param key
             * @param value
             * @return
             */
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount();
            }
        };
    }

    //1:存
    public void saveBitmap(String key,Bitmap value) {
        mLruCache.put(key, value);
    }
    //2:取
    public Bitmap getBitmap(String key) {
        return mLruCache.get(key);
    }



    public  void getImage(final ImageView img, final String url) {
        //网络请求
        if (img.getTag().equals(url)) {
            //内存中有的话 直接从内存中取出来
            Bitmap bitmap = getBitmap(url);
            if (bitmap!=null) {
                img.setImageBitmap(bitmap);
                return;
            }

            HttpUtils.getAsyncData(url, new HttpUtils.IPostData() {
                @Override
                public void success(byte[] data) {
                    Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length);
                    img.setImageBitmap(bm);
                    //没有的话 网络加载 存起来
                    saveBitmap(url,bm);
                }

                @Override
                public void error(String error) {

                }
            });

        }

    }
}

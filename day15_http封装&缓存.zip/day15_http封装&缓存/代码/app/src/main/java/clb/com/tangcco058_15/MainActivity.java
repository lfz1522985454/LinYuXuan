package clb.com.tangcco058_15;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Handler
    //
    private ImageView iv_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv_img = (ImageView) findViewById(R.id.iv_img);
    }

    public void getData(View view) {
        //ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,}, 1);
        //
        //url -->byte[]
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                byte[] data = HttpUtils.getData("http://api.hanju.koudaibaobao.com/api/star/index");
//                //data-->JSON
//                final String result = new String(data);
//
//                //Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
//                //只能在子线程调用
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        //执行在主线程
//                        Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
//                    }
//                });
//            }
//        }).start();

        HttpUtils.getAsyncData("http://api.hanju.koudaibaobao.com/api/star/index", new HttpUtils.IPostData() {
            @Override
            public void success(byte[] data) {
                Toast.makeText(MainActivity.this, new String(data), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void error(String error) {
                Toast.makeText(MainActivity.this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void downloadImg(View view) {
        HttpUtils.getAsyncData("http://res.hanju.koudaibaobao.com/hj_res/FvIXN0oZZrTrcxFVPP8AzhZKhWSy.jpg", new HttpUtils.IPostData() {
            @Override
            public void success(byte[] data) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                iv_img.setImageBitmap(bitmap);

            }

            @Override
            public void error(String error) {

            }
        });
    }
}

package clb.com.tangcco058_15;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {
    private ListView mListView;
    private List<HotStars> mHotStarses = new ArrayList<>();
    private ImageLoader mImageLoader;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        mListView = (ListView) findViewById(R.id.mListView);

        HttpUtils.getAsyncData("http://api.hanju.koudaibaobao.com/api/star/index", new HttpUtils.IPostData() {
            @Override
            public void success(byte[] data) {
                //--String
                String json = new String(data);
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    JSONArray jsonArray = jsonObject.getJSONArray("hotStars");
                    HotStars hotStars;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        String name = jsonObject.getString("name");
                        hotStars = new HotStars();
                        hotStars.setName(name);
                        hotStars.setThumb(jsonObject.getString("thumb"));
                        mHotStarses.add(hotStars);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                MyAdapter myAdapter = new MyAdapter();
                mListView.setAdapter(myAdapter);
            }

            @Override
            public void error(String error) {

            }
        });


    }

    class MyAdapter extends BaseAdapter {
        public MyAdapter() {
            mImageLoader = new ImageLoader();
        }

        @Override
        public int getCount() {
            return mHotStarses.size();
        }

        @Override
        public HotStars getItem(int position) {
            return mHotStarses.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final ViewHolder holder;
            if (convertView == null) {
                holder = new ViewHolder();
                convertView = LayoutInflater.from(SecondActivity.this).inflate(R.layout.item, parent, false);
                holder.iv_item = (ImageView) convertView.findViewById(R.id.iv_item);
                holder.tv_item = (TextView) convertView.findViewById(R.id.tv_item);

                convertView.setTag(holder);

            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            //解决图片错位1:setTag
            holder.iv_item.setTag(getItem(position).getThumb());//保证tag唯一
            holder.iv_item.setImageResource(R.mipmap.ic_launcher);

            holder.tv_item.setText(getItem(position).getName());
            mImageLoader.getImage(holder.iv_item,getItem(position).getThumb());

            //2:判断tag的值 是否正是图片的网址

//            HttpUtils.getAsyncData(getItem(position).getThumb(), new HttpUtils.IPostData() {
//                @Override
//                public void success(byte[] data) {
//                    Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
//                    holder.iv_item.setImageBitmap(bitmap);
//                }
//
//                @Override
//                public void error(String error) {
//
//                }
//            });


            return convertView;
        }

        class ViewHolder {
            ImageView iv_item;
            TextView tv_item;
        }
    }


}

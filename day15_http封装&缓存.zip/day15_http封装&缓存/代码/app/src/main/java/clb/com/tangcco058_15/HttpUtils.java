package clb.com.tangcco058_15;

import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by cuilibao on 2017/9/8.
 */

public class HttpUtils {
    //创建在主线程 Looper.getMainLooper()
    static Handler mHandler = new Handler(Looper.getMainLooper());

    public static byte[] getData(String path) {
        try {
            URL url = new URL(path);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setReadTimeout(2000);
            connection.setConnectTimeout(2000);

            //返回码
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                //得到流
                InputStream inputStream = connection.getInputStream();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();

                //-->byte

                int len = 0;
                byte[] bytes = new byte[1024];
                while ((len = inputStream.read(bytes)) != -1) {

                    baos.write(bytes, 0, len);
                }

                byte[] data = baos.toByteArray();
                return data;

            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


    /**
     * 实现异步的请求:
     * 请求直接拿到数据 : 同步
     * 请求之后 要有一个回调 请求成功  请求失败 接口
     *
     * @param path
     * @return
     */
    public static void getAsyncData(final String path, final IPostData postData) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(path);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setReadTimeout(2000);
                    connection.setConnectTimeout(2000);

                    //返回码
                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        //得到流
                        InputStream inputStream = connection.getInputStream();
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();

                        //-->byte

                        int len = 0;
                        byte[] bytes = new byte[1024];
                        while ((len = inputStream.read(bytes)) != -1) {

                            baos.write(bytes, 0, len);
                        }
                        final byte[] data = baos.toByteArray();

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                //主线程
                                postData.success(data);
                            }
                        });

                    }
                } catch (final MalformedURLException e) {
                    e.printStackTrace();
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            postData.error(e.getMessage());

                        }
                    });
                } catch (final IOException e) {
                    e.printStackTrace();
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            postData.error(e.getMessage());

                        }
                    });
                }

            }
        }).start();


    }

    //定义一个接口
    interface IPostData {
        //1:成功
        void success(byte[] data);

        //2:失败
        void error(String error);
    }

}

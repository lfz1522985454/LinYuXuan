package clb.com.tangcco058_07.homework;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_07.R;

public class MainActivity extends AppCompatActivity {
    private EditText editText;
    private Button button;
    private ListView mListView;
    //BaseAdapter
    private List<String> mData = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = (EditText) findViewById(R.id.edit_input);
        button = (Button) findViewById(R.id.btn_submit);
        mListView = (ListView) findViewById(R.id.mListView);
        //改变数据源  重新setAdapter
        editText.getText().toString();
        //文字改变触发的监听
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (editText.getText().toString().length() > 0) {
                    //改变Button的文字
                    button.setText("确定");

                } else {
                    button.setText("取消");

                }
            }
        });


        //适配器
        //空
        adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                mData//空
        );

        mListView.setAdapter(adapter);
    }

    public void submitOrCancel(View view) {
        //输入内容添加到ListView中
        //判断有没有输入内容
        String result = editText.getText().toString();
        if (result.length() <= 0) {
            Toast.makeText(this, "请输入内容", Toast.LENGTH_SHORT).show();
            return;
        }

        mData.add(result);
        //刷新适配器
        mListView.setAdapter(adapter);
        editText.setText("");

    }

    public void btn_clear(View view) {
        mData.clear();
        mListView.setAdapter(adapter);
    }
}

package clb.com.tangcco058_07.today;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_07.R;

public class MyGridActivity extends AppCompatActivity {
    private GridView mGridView;
    private List<Person> persons = new ArrayList<>();
    private MyGridAdapter myAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_grid);
        mGridView = (GridView) findViewById(R.id.mGridView);
        addData();

        //

        //适配器
        myAdapter = new MyGridAdapter(persons);

        //添加到适配器
        mGridView.setAdapter(myAdapter);
        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MyGridActivity.this, "" + position, Toast.LENGTH_SHORT).show();

            }
        });
        mGridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                //删除当前item
                //更新视图
                //alert()
                AlertDialog.Builder builder = new AlertDialog.Builder(MyGridActivity.this)
                        .setTitle("删除条目").setIcon(R.mipmap.ic_launcher).setMessage("确定么?")
                        //Positive 积极的
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //删除条目
                                //persons.get(position);
                                persons.remove(position);
                                //更新  setAdapter:重新开始渲染
                                //mGridView.setAdapter(myAdapter);
                                //在原有基础上 渲染 不会跑到顶部
                                myAdapter.notifyDataSetChanged();

                                //数据源改变调用才有效

                            }
                            //消极的
                        }).setNegativeButton("取消", null);
                builder.show();
                return true;
            }
        });
//        mGridView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });

    }

    private void addData() {
        Person person;
        for (int i = 0; i < 50; i++) {
            person = new Person(i, R.mipmap.ic_launcher, "张" + i);
            persons.add(person);

        }
    }
}

package clb.com.tangcco058_07.today;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import clb.com.tangcco058_07.R;

/**
 * Created by cuilibao on 2017/8/21.
 */

public class MyAdapter extends BaseAdapter {

    private List<Person> persons;

    public MyAdapter(List<Person> persons) {
        this.persons = persons;
    }


    @Override
    public int getCount() {
        return persons.size();
    }

    @Override
    public Person getItem(int position) {
        return persons.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        //没有人来
        if (convertView == null) {
            Log.d("TAG", "getView: " + position);
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);

            holder = new ViewHolder();
            holder.imageView = (ImageView) convertView.findViewById(R.id.imageView);
            holder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
            holder.tv_age = (TextView) convertView.findViewById(R.id.tv_age);

            //留下资源再走!!!!
            //设置标签  方便再次查找
            convertView.setTag(holder);
        } else {
            //有资源
            holder = (ViewHolder) convertView.getTag();
        }

        Person person = persons.get(position);
        holder.imageView.setImageResource(person.getImgHead());
        holder.tv_name.setText(person.getName());
        holder.tv_age.setText(String.valueOf(person.getAge()));

        return convertView;
    }

    private class ViewHolder {
        ImageView imageView;
        TextView tv_name, tv_age;
    }
}

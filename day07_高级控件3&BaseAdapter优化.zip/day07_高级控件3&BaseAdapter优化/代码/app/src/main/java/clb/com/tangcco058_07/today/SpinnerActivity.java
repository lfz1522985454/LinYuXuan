package clb.com.tangcco058_07.today;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_07.R;

public class SpinnerActivity extends AppCompatActivity {
    private Spinner mSpinner;
    private List<String> mData = new ArrayList<>();


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);
        mSpinner = (Spinner) findViewById(R.id.mSpinner);
        //数据源
        addData();
        // 适配器
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,

                mData
        );
        mSpinner.setAdapter(adapter);

//        mSpinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(SpinnerActivity.this, ""+position, Toast.LENGTH_SHORT).show();
//            }
//        });

        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /**
             * 选中
             * @param parent
             * @param view
             * @param position
             * @param id
             */
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(SpinnerActivity.this, "位置" + position, Toast.LENGTH_SHORT).show();
            }

            /**
             * 没选中
             * @param parent
             */
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void addData() {
        for (int i = 0; i < 100; i++) {
            mData.add("我有" + i + "个小姐姐");
        }
    }
}

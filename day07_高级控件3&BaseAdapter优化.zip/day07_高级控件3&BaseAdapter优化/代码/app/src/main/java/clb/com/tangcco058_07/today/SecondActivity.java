package clb.com.tangcco058_07.today;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_07.R;
import clb.com.tangcco058_07.weight.XListView;

public class SecondActivity extends AppCompatActivity {
    private XListView mListView;
    private List<Person> persons = new ArrayList<>();
    //private Timer timer;
    private Handler handler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        mListView = (XListView) findViewById(R.id.mListView);
        //timer = new Timer();
        handler = new Handler();
        addData();

        //适配器
        MyAdapter myAdapter = new MyAdapter(persons);

        //添加到适配器
        mListView.setAdapter(myAdapter);

        mListView.setXListViewListener(new XListView.IXListViewListener() {
            //刷新
            @Override
            public void onRefresh() {
                //模拟一下 2s之后 停止加载
                //setInterval(function,30)
//                timer.schedule(new TimerTask() {
//                    @Override
//                    public void run() {
//                        mListView.stopRefresh();
//                    }
//                }, 2000);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //数据源改变
                        //setAdapter
                        //notifiDataSetChange()//刷新的时候 不会回到顶部
                        mListView.stopRefresh();
                    }
                }, 2000);

            }

            //加载
            @Override
            public void onLoadMore() {
//                timer.schedule(new TimerTask() {
//                    @Override
//                    public void run() {
//                        mListView.stopLoadMore();
//                    }
//                }, 2000);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mListView.stopLoadMore();
                    }
                }, 2000);
            }
        });


//        //布局  View
//        View view = LayoutInflater.from(this).inflate(R.layout.headview_layout, null);
//        mListView.addHeaderView(view);
//
//        mListView.addFooterView(view);
//
//        //1:动画 自定义的ListView

    }

    private void addData() {
        Person person;
        for (int i = 0; i < 50; i++) {
            person = new Person(i, R.mipmap.ic_launcher, "张" + i);
            persons.add(person);

        }
    }
}

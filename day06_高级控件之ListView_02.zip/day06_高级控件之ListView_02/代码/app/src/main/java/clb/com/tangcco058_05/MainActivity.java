package clb.com.tangcco058_05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private FNRadioGroup mGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mGroup = (FNRadioGroup) findViewById(R.id.mGroup);
        //设置边距
        mGroup.setChildMargin(10, 10, 0, 0);
        mGroup.setOnCheckedChangeListener(new FNRadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(FNRadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_1:
                        Toast.makeText(MainActivity.this, "1", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.rb_2:
                        Toast.makeText(MainActivity.this, "2", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.rb_3:
                        Toast.makeText(MainActivity.this, "3", Toast.LENGTH_SHORT).show();

                        break;
                    case R.id.rb_4:
                        Toast.makeText(MainActivity.this, "4", Toast.LENGTH_SHORT).show();

                        break;

                }
            }
        });
    }
}

package clb.com.tangcco058_05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_05.adapter.MyAdapter;
import clb.com.tangcco058_05.bean.Person;

public class MyListActivity extends AppCompatActivity {
    private ListView mListView;
    private TextView tv_bottom;
    private List<Person> persons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        mListView = (ListView) findViewById(R.id.mListView);
        tv_bottom = (TextView) findViewById(R.id.tv_bottom);

        //数据源
        addData();
        //适配器中
        MyAdapter adapter = new MyAdapter();
        adapter.setPersons(persons);
        mListView.setAdapter(adapter);


        //设置ListView的点击事件
//        mListView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MyListActivity.this, "hahaha", Toast.LENGTH_SHORT).show();
//            }
//        });


        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MyListActivity.this, position + "", Toast.LENGTH_SHORT).show();
            }
        });

        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MyListActivity.this, "长按"+position, Toast.LENGTH_SHORT).show();
                //true : 长按不会调用单击事件  false :出发单击事件 事件拦截分发机制
                return true;
            }
        });

        //Scroll 滚动
        mListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            //State 状态
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                //真实开发
                switch (scrollState) {
                    //TOUCH 触摸
                    case SCROLL_STATE_TOUCH_SCROLL:
                        //System.out.print();
                        Log.d("TAG", "触摸");
                        break;
                    //IDLE 空闲 加载
                    case SCROLL_STATE_IDLE:
                        Log.d("TAG", "空闲");
                        break;
                    //FLING 飞 不要加载图片
                    case SCROLL_STATE_FLING:
                        Log.d("TAG", "飞起");
                        break;
                }
            }


            @Override
            public void onScroll(AbsListView view,
                                 int firstVisibleItem,//第一个显示的条目
                                 int visibleItemCount, //显示条目的数量
                                 int totalItemCount) {//条目的总数

                //如何判断是否到达底部
                if (totalItemCount - firstVisibleItem == visibleItemCount) {
                    tv_bottom.setVisibility(View.VISIBLE);

                } else {
                    tv_bottom.setVisibility(View.GONE);

                }

            }
        });




        //Spinner
//        mListView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MyListActivity.this, position+"", Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
    }

    private void addData() {
        Person person;
        for (int i = 0; i < 20; i++) {
            person = new Person("张三", 20, R.mipmap.ic_launcher);
            persons.add(person);
        }

    }


}

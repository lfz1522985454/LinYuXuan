package clb.com.tangcco058_05.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import clb.com.tangcco058_05.R;
import clb.com.tangcco058_05.bean.Person;

public class MyAdapter extends BaseAdapter {

    //拿到数据源
    //1:什么方法用来在一个类到另一个类传值 构造
    private List<Person> persons;

//    public MyAdapter(List<Person> persons) {
//        this.persons = persons;
//    }
//
//


    public void setPersons(List<Person> persons) {
        this.persons = persons;
    }

    //
    //Intent  Activity/四大组件
    @Override
    public int getCount() {
        return persons.size();
    }

    @Override
    public Object getItem(int position) {
        return persons.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //将布局转化成View
        //parent.getContext() 得到Activity 的上下文对象
        convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.person_item_layout, parent, false);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.imageView);
        TextView tv_name = (TextView) convertView.findViewById(R.id.tv_name);
        TextView tv_age = (TextView) convertView.findViewById(R.id.tv_age);

        imageView.setImageResource(persons.get(position).getImgHead());
        tv_name.setText(persons.get(position).getName());
        tv_age.setText(String.valueOf(persons.get(position).getAge()));

        return convertView;
    }
}

package clb.com.tangcco058_05.bean;

/**
 * Created by cuilibao on 2017/8/18.
 */

public class Person  {
    private String name;
    private int age;
    private int imgHead;

    public Person(String name, int age, int imgHead) {
        this.name = name;
        this.age = age;
        this.imgHead = imgHead;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getImgHead() {
        return imgHead;
    }

    public void setImgHead(int imgHead) {
        this.imgHead = imgHead;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

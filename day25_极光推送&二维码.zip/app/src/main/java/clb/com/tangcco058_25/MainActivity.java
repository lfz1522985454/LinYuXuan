package clb.com.tangcco058_25;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.xys.libzxing.zxing.activity.CaptureActivity;
import com.xys.libzxing.zxing.encoding.EncodingUtils;

public class MainActivity extends AppCompatActivity {
    private TextView tv_result;
    private EditText edit_input;
    private ImageView image_shengcheng;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_result = (TextView) findViewById(R.id.tv_result);
        edit_input = (EditText) findViewById(R.id.edit_input);
        image_shengcheng = (ImageView) findViewById(R.id.image_shengcheng);

    }

    public void scan(View view) {
        Intent intent = new Intent(this, CaptureActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String result = data.getStringExtra("result");
            tv_result.setText(result);

        }
    }

    public void shengcheng(View view) {
        String input = edit_input.getText().toString();
        Bitmap qrCode = EncodingUtils.createQRCode(input, 300, 300, null);
        image_shengcheng.setImageBitmap(qrCode);

    }
}

package clb.com.tangcco058_24;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

/**
 * Created by cuilibao on 2017/10/10.
 *
 * 变:   泛型参数
 * 不变  封装
 *
 *
 * 继承  封装  泛型
 *
 * <T>:数据源类型   D   Z
 */

public abstract class CommonBaseAdapter<T> extends BaseAdapter {
    private List<T> mPersons;
    private Context mContext;
    private int mLayoutRes;

    public CommonBaseAdapter(Context context, List<T> persons, @LayoutRes int layoutRes) {
        mContext = context;
        mPersons = persons;
        mLayoutRes = layoutRes;
    }

    @Override
    public int getCount() {
        return mPersons.size();
    }

    @Override
    public T getItem(int position) {
        return mPersons.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1:初始化
        //2:判断是否为空
        //3:setTag getTag
        //4:赋值
        //5:返回 convertView

        //已经初始化过的View
        ViewHolder viewHolder = ViewHolder.getViewHolder(position, convertView, parent, mContext, mLayoutRes);

        View view = viewHolder.getConvertView();

        T t = getItem(position);
        getCurrentValue(viewHolder, position, t);

        return view;
    }

    //抽象方法
    public abstract void getCurrentValue(ViewHolder viewHolder,int position,T t);//控件 位置  当前条目对应的数据
}

package clb.com.tangcco058_24;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.LayoutRes;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by cuilibao on 2017/10/10.
 */

public class ViewHolder {
    private View convertView;
    private SparseArray<View> views;//SparseArray 稀疏数组  List<> 更高的效率

    public ViewHolder(int position, View convertView, ViewGroup parent, Context context, @LayoutRes int LayoutRes) {
        //初始化
        convertView = LayoutInflater.from(context).inflate(LayoutRes, parent, false);
        //方便在下面使用
        this.convertView = convertView;
        views = new SparseArray<>();
        //setTag
        convertView.setTag(this);
    }

    public static ViewHolder getViewHolder(int position, View convertView, ViewGroup parent, Context context, @LayoutRes int LayoutRes) {
        ViewHolder viewHolder = null;
        if (convertView == null) {
            //初始化布局 初始化控件
            viewHolder = new ViewHolder(position, convertView, parent, context, LayoutRes);
        } else {
            //取出来
            //getTag
            viewHolder = (ViewHolder) convertView.getTag();
        }
        return viewHolder;

    }

    //在getView里面调用
    public View getConvertView() {
        return convertView;
    }


    //图片  文字
    //setText 设置文字

    /**
     * @param viewId 控件的id
     * @param text   文本的内容
     */
    public void setText(int viewId, String text) {
        //findviewById  没有初始化的时候
        TextView textView = (TextView) views.get(viewId);
        if (textView == null) {
            textView = (TextView) convertView.findViewById(viewId);
            //存储数组中
            views.put(viewId, textView);
        }
        textView.setText(text);

    }

    //setImage

    /**
     * @param viewId 控件的id
     * @param ResImg   图片
     */
    public void setImage(int viewId, int ResImg) {
        //findviewById  没有初始化的时候
        ImageView imageView = (ImageView) views.get(viewId);
        if (imageView == null) {
            imageView = (ImageView) convertView.findViewById(viewId);
            //存储数组中
            views.put(viewId, imageView);
        }
        imageView.setImageResource(ResImg);

    }

    public void setImage(int viewId, Bitmap bitmap) {
        //findviewById  没有初始化的时候
        ImageView imageView = (ImageView) views.get(viewId);
        if (imageView == null) {
            imageView = (ImageView) convertView.findViewById(viewId);
            //存储数组中
            views.put(viewId, imageView);
        }
        imageView.setImageBitmap(bitmap);

    }


    public View getView(int viewId) {
        //findviewById  没有初始化的时候
        return views.get(viewId);
    }


}

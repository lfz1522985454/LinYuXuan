package clb.com.tangcco058_24;

import android.content.Context;
import android.support.annotation.LayoutRes;

import java.util.List;

/**
 * Created by cuilibao on 2017/10/10.
 */

public class MyListAdapter extends CommonBaseAdapter<Person> {


    public MyListAdapter(Context context, List<Person> persons, @LayoutRes int layoutRes) {
        super(context, persons, layoutRes);
    }

    @Override
    public void getCurrentValue(ViewHolder viewHolder, int position, Person person) {
        viewHolder.setText(R.id.textView, person.getName());
//        viewHolder.setText(R.id.textView1);
        //Glide

        viewHolder.setImage(R.id.imageView, person.getImgRes());
        //viewHolder.get


    }
}

package clb.com.tangcco058_24;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    private List<Person> persons = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView = (ListView) findViewById(R.id.mListView);
        addData();
        //mListView.setAdapter(new CommonAdapter(this, persons));
        mListView.setAdapter(new MyListAdapter(this, persons, R.layout.item));

//        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//            }
//        });
    }

    private void addData() {
        for (int i = 0; i < 20; i++) {
            Person person = new Person();
            if (i % 2 == 0) {
                person.setImgRes(R.mipmap.ic_launcher);
            } else {
                person.setImgRes(R.mipmap.btn_rating_star_on_normal);
            }
            person.setName("张" + i);
            persons.add(person);

        }
    }
}

package clb.com.tangcco058_24;

/**
 * Created by cuilibao on 2017/10/10.
 */
public class Person {
    private String name;
    private int imgRes;

    public int getImgRes() {
        return imgRes;
    }

    public void setImgRes(int imgRes) {
        this.imgRes = imgRes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

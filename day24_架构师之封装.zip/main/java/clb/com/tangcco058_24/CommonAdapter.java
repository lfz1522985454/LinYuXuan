package clb.com.tangcco058_24;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by cuilibao on 2017/10/10.
 */

public class CommonAdapter extends BaseAdapter {
    private List<Person> mPersons;
    private Context mContext;

    public CommonAdapter(Context context,List<Person> persons) {
        mContext = context;
        mPersons = persons;
    }

    @Override
    public int getCount() {
        return mPersons.size();
    }

    @Override
    public Object getItem(int position) {
        return mPersons.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1:初始化
        //2:判断是否为空
        //3:setTag getTag
        //4:赋值
        //5:返回 convertView

        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item, parent, false);
            holder.mImageView = (ImageView) convertView.findViewById(R.id.imageView);
            holder.mTextView = (TextView) convertView.findViewById(R.id.textView);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.mTextView.setText(mPersons.get(position).getName());
        holder.mImageView.setImageResource(mPersons.get(position).getImgRes());

        return convertView;
    }

    class ViewHolder {
        ImageView mImageView;
        TextView mTextView;

    }


}

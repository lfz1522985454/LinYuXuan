package clb.com.tangcco058_17;

import android.app.Application;

import org.xutils.x;

/**
 * Created by cuilibao on 2017/9/13.
 */

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        x.Ext.init(this);
    }
}

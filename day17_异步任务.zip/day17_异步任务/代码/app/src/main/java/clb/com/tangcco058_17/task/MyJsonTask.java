package clb.com.tangcco058_17.task;

import android.os.AsyncTask;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import clb.com.tangcco058_17.bean.Destinations;
import clb.com.tangcco058_17.uitls.HttpUtils;

/**
 * Created by cuilibao on 2017/9/13.
 */

public class MyJsonTask extends AsyncTask<String, Void, List<Destinations>> {

    @Override
    protected List<Destinations> doInBackground(String... params) {
        byte[] result = HttpUtils.getJson(params[0]);
        String json = new String(result);
        //解析
        //
        Gson gson = new Gson();
/*
        gson.fromJson()//将一个json转化成对象
*/

/*
        gson.toJson();//将一个对象转成json
*/
        List<Destinations> list = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                JSONArray destinations = jsonObject.getJSONArray("destinations");
                for (int j = 0; j < destinations.length(); j++) {
                    Destinations des = new Destinations();
                    jsonObject = destinations.getJSONObject(j);

                    des.setImage_url(jsonObject.getString("image_url"));
                    des.setName_zh_cn(jsonObject.getString("name_zh_cn"));
                    list.add(des);

                }
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    protected void onPostExecute(List<Destinations> mData) {
        //数据源
        //Gridview
        super.onPostExecute(mData);

        //怎么传到Activity
        mLinstener.getData(mData);
    }

    public interface IGetListLinstener{
        void getData(List<Destinations> beanList);
    }

    //2:初始化
    private IGetListLinstener mLinstener;

    //3:赋值
    public void setLinstener(IGetListLinstener linstener) {
        mLinstener = linstener;
    }

    //4:


}

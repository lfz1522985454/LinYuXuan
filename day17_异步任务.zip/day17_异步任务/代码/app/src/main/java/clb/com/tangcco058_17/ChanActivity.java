package clb.com.tangcco058_17;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;

import java.util.List;

import clb.com.tangcco058_17.adapter.MyAdapter;
import clb.com.tangcco058_17.bean.Destinations;
import clb.com.tangcco058_17.task.MyJsonTask;

public class ChanActivity extends AppCompatActivity implements MyJsonTask.IGetListLinstener{
    private GridView mGridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chan);
        mGridView = (GridView) findViewById(R.id.mGridView);

        //数据源
        MyJsonTask myJsonTask = new MyJsonTask();
        myJsonTask.setLinstener(this);
        myJsonTask.execute("http://chanyouji.com/api/destinations.json?page=1");

        //适配器
    }

    /**
     * 主线程
     * @param beanList
     */
    @Override
    public void getData(List<Destinations> beanList) {
        //图片
        //网络请求
        Log.d("TAG", "getData: " + beanList.toString());
        mGridView.setAdapter(new MyAdapter(beanList));

    }
}

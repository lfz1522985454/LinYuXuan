package clb.com.tangcco058_17;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private ProgressBar mProgress;
    private ImageView iv_download;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mProgress = (ProgressBar) findViewById(R.id.mProgress);
        iv_download = (ImageView) findViewById(R.id.iv_download);


    }

    public void getBitMap(View view) {
        //Handler sendMessage() 如果没有接受的话 垃圾回收 OOM异常
        //xUtils
        //异步任务  start()  .execute()执行一个异步任务
        new MyTask().execute("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1505293664729&di=24565bcc4215cbd9738d667559748f6a&imgtype=0&src=http%3A%2F%2Fimg3.100bt.com%2Fupload%2Fttq%2F20130921%2F1379723611879_middle.jpg");

    }

    /**
     * Url:可变数组
     * Void:进度,
     * Bitmap:返回的结果
     */
    class MyTask extends AsyncTask<String, Void, Bitmap> {
        /**
         * doinbackground之前执行的方法
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgress.setVisibility(View.VISIBLE);

        }

        /**
         * 子线程 耗时操作
         * String ... 可变数组
         * @param params:
         * @return Bitmap
         */
        @Override
        protected Bitmap doInBackground(String... params) {
            try {
                URL url = new URL(params[0]);
                InputStream inputStream = url.openStream();
                return BitmapFactory.decodeStream(inputStream);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        /**
         * 耗时操作执行结束之后执行方法
         * @param bitmap
         */
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            mProgress.setVisibility(View.GONE);
            iv_download.setImageBitmap(bitmap);

        }
    }

}

package clb.com.tangcco058_17.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.xutils.common.util.DensityUtil;
import org.xutils.image.ImageOptions;
import org.xutils.x;

import java.util.List;

import clb.com.tangcco058_17.R;
import clb.com.tangcco058_17.bean.Destinations;

/**
 * Created by cuilibao on 2017/9/13.
 */

public class MyAdapter extends BaseAdapter {
    private List<Destinations> mDestinationses;

    public MyAdapter(List<Destinations> destinationses) {
        mDestinationses = destinationses;
    }

    @Override
    public int getCount() {
        return mDestinationses.size();
    }

    @Override
    public Object getItem(int position) {
        return mDestinationses.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            //
            holder = new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
            holder.iv_name = (ImageView) convertView.findViewById(R.id.item_iv);
            holder.tv_name = (TextView) convertView.findViewById(R.id.item_tv);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Destinations destinations = mDestinationses.get(position);
        String image_url = destinations.getImage_url();
        holder.iv_name.setImageResource(R.mipmap.ic_launcher);
        holder.tv_name.setText(destinations.getName_zh_cn());

        ImageOptions imageOptions = new ImageOptions.Builder()
                .setSize(DensityUtil.dip2px(120), DensityUtil.dip2px(120))//图片大小
                .setRadius(DensityUtil.dip2px(5))//ImageView圆角半径
                .setCrop(true)// 如果ImageView的大小不是定义为wrap_content, 不要crop.
                .setImageScaleType(ImageView.ScaleType.CENTER_CROP)
                .setLoadingDrawableId(R.mipmap.ic_launcher)//加载中默认显示图片
                .setFailureDrawableId(R.mipmap.ic_launcher)//加载失败后默认显示图片
                .build();

        x.image().bind(holder.iv_name, image_url,imageOptions);

//        x.http().get(new RequestParams(image_url), new Callback.CommonCallback<byte[]>() {
//            @Override
//            public void onSuccess(byte[] bytes) {
//                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
//                holder.iv_name.setImageBitmap(bitmap);
//            }
//
//            @Override
//            public void onError(Throwable throwable, boolean b) {
//                Log.d("TAG", "onError: " + throwable.getMessage());
//            }
//
//            @Override
//            public void onCancelled(CancelledException e) {
//
//            }
//
//            @Override
//            public void onFinished() {
//
//            }
//        });



        return convertView;
    }

    class ViewHolder {

        TextView tv_name;
        ImageView iv_name;

    }
}

package clb.com.tangcco058_17.uitls;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by cuilibao on 2017/9/13.
 */

public class HttpUtils {
    public static byte[] getJson(String path) {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(path).openConnection();
            connection.setRequestMethod("GET");
            connection.setReadTimeout(2000);
            connection.setConnectTimeout(2000);

            if (connection.getResponseCode() == 200) {
                InputStream inputStream = connection.getInputStream();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();

                int len = 0;
                byte[] bytes = new byte[1024];
                while ((len = inputStream.read(bytes)) != -1) {
                    baos.write(bytes, 0, len);
                }
                return baos.toByteArray();

            }

        } catch (IOException e) {
            e.printStackTrace();

        }

        return new byte[0];
    }

}

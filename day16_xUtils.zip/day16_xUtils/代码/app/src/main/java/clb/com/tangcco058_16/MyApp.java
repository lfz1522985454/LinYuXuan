package clb.com.tangcco058_16;

import android.app.Application;

import org.xutils.x;

/**
 * Created by cuilibao on 2017/9/11.
 */

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //注册xUtils
        x.Ext.init(this);
        //显示错误的信息
        x.Ext.setDebug(true);

    }
}

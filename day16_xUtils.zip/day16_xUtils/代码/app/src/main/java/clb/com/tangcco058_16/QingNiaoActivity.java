package clb.com.tangcco058_16;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

public class QingNiaoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qing_niao);
    }

    public void login(View view) {
        RequestParams params = new RequestParams("http://a.bdqn.cn/pb/pbsub/web/login/user_login.action");
        params.addBodyParameter("clientType","009");
        params.addBodyParameter("encrypt","03860b86b169663607b9fd43785cd7ef");
        params.addBodyParameter("passport","1537898081@qq.com");
        params.addBodyParameter("password","f7f91da4f7f459a5d3a697890967bb0e");

        x.http().post(params, new Callback.CommonCallback<String>() {
            @Override
            public void onSuccess(String result) {
                //Toast.makeText(QingNiaoActivity.this, result, Toast.LENGTH_SHORT).show();
                //登录成功之后
                //进入到主页面
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String code = jsonObject.getString("code");
                    if (code.equals("1")) {
                        startActivity(new Intent(QingNiaoActivity.this, SecondActivity.class));
                        Toast.makeText(QingNiaoActivity.this, "欢迎你!   " + jsonObject.getString("userName"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(QingNiaoActivity.this, "登录失败", Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError(Throwable throwable, boolean b) {
                Toast.makeText(QingNiaoActivity.this, throwable.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(CancelledException e) {

            }

            @Override
            public void onFinished() {

            }
        });
    }
}

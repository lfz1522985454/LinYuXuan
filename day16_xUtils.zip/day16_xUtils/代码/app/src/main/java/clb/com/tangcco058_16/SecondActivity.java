package clb.com.tangcco058_16;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {
    private ListView mListView;
    private ViewPager mViewPager;//view的集合
    private List<String> imgHeadurls = new ArrayList<>();
    private ImageView mImageView;
    //装载Viewpager数据源的集合
    private List<ImageView> mViews = new ArrayList<>();
    private MyViewPagerAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        mListView = (ListView) findViewById(R.id.mListView);
        //时间戳 1970 0 0 --->现在的毫秒数
        long l = System.currentTimeMillis();
        //ListView 添加一个
        View headView = LayoutInflater.from(this).inflate(R.layout.viewpager_head, null);
        mViewPager = (ViewPager) headView.findViewById(R.id.head_viewPager);
        mListView.addHeaderView(headView);

        List<String> stringList = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            stringList.add("我有" + i + "个老婆");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                stringList
        );
        mListView.setAdapter(adapter);
        mAdapter = new MyViewPagerAdapter();
        mViewPager.setAdapter(mAdapter);


        //数据源
        RequestParams params = new RequestParams("http://apiv4.yangkeduo.com/subjects?pdduid=");

        x.http().get(params, new Callback.CommonCallback<String>() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONArray jsonArray = new JSONArray(result);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String home_banner_2 = jsonObject.getString("home_banner_2");
                        //数据源-->View ImageView
                        //怎么转化成图片
                        imgHeadurls.add(home_banner_2);

                        RequestParams params = new RequestParams(imgHeadurls.get(i));

                        x.http().get(params, new Callback.CommonCallback<byte[]>() {
                            @Override
                            public void onSuccess(byte[] bytes) {
                                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

                                mImageView = new ImageView(SecondActivity.this);
                                ViewGroup.LayoutParams paramsImg = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                                mImageView.setLayoutParams(paramsImg);
                                mImageView.setImageBitmap(bitmap);
                                //添加到ViewPager中
                                mViews.add(mImageView);
                                //mViewPager.setAdapter(mAdapter);
                                mAdapter.notifyDataSetChanged();
                            }

                            @Override
                            public void onError(Throwable throwable, boolean b) {

                            }

                            @Override
                            public void onCancelled(CancelledException e) {

                            }

                            @Override
                            public void onFinished() {

                            }
                        });
                    }





                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }

            @Override
            public void onError(Throwable throwable, boolean b) {

            }

            @Override
            public void onCancelled(CancelledException e) {

            }

            @Override
            public void onFinished() {

            }
        });

        //适配器

    }

    class MyViewPagerAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return mViews.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(final ViewGroup container, int position) {
            container.addView(mViews.get(position));
            return mViews.get(position);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            //super.destroyItem(container, position, object);
            container.removeView(mViews.get(position));
        }
    }
}


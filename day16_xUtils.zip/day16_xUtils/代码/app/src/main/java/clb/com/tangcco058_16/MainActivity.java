package clb.com.tangcco058_16;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

public class MainActivity extends AppCompatActivity {
    private ImageView iv_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv_img = (ImageView) findViewById(R.id.iv_img);

    }

    public void doGet(View view) {
        //网络请求
        RequestParams params = new RequestParams("http://www.beevideo.tv:7855/api/beeAssist/listStartPic.action?borqsPassport=QsECtIhs0tROzdbvSdf8JwW2FAsKlSLzBXcVqdPyHodtyG_L7ryaMZFlNr62wbtp&version=2");

        x.http().get(params, new Callback.CommonCallback<byte[]>() {
            /**
             * 成功
             * @param bytes
             */
            @Override
            public void onSuccess(byte[] bytes) {
                String result = new String(bytes);
                Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
            }

            /**
             * 失败
             * @param throwable
             * @param b
             */
            @Override
            public void onError(Throwable throwable, boolean b) {
                Toast.makeText(MainActivity.this, throwable.getMessage(), Toast.LENGTH_SHORT).show();
            }

            /**
             * 取消
             * @param e
             */
            @Override
            public void onCancelled(CancelledException e) {

            }

            /**
             * 完成
             */
            @Override
            public void onFinished() {

            }
        });
    }

    public void download(View view) {
        //下载图片
        RequestParams params = new RequestParams("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1505120808186&di=54d27c3b1355a06d1a8391ce23b100cf&imgtype=0&src=http%3A%2F%2Fp2.image.hiapk.com%2Fuploads%2Fallimg%2F150318%2F7730-15031Q44P5.jpg");
        x.http().get(params, new Callback.CommonCallback<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                iv_img.setImageBitmap(bitmap);
            }

            @Override
            public void onError(Throwable throwable, boolean b) {

            }

            @Override
            public void onCancelled(CancelledException e) {

            }

            @Override
            public void onFinished() {

            }
        });
    }

    public void doPost(View view) {
        //下载图片
        RequestParams params = new RequestParams("http://www.beevideo.tv:7855/api/beeAssist/listStartPic.action");
        params.addBodyParameter("borqsPassport","QsECtIhs0tROzdbvSdf8JwW2FAsKlSLzBXcVqdPyHodtyG_L7ryaMZFlNr62wbtp");
        params.addBodyParameter("version", "2");
        //?borqsPassport=QsECtIhs0tROzdbvSdf8JwW2FAsKlSLzBXcVqdPyHodtyG_L7ryaMZFlNr62wbtp&version=2
        x.http().get(params, new Callback.CommonCallback<String>() {
            @Override
            public void onSuccess(String result) {
                Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Throwable throwable, boolean b) {

            }

            @Override
            public void onCancelled(CancelledException e) {

            }

            @Override
            public void onFinished() {

            }
        });
    }
}

package clb.com.tangcco058_22;

import android.app.Service;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

/**
 * Created by cuilibao on 2017/9/26.
 */

public class DownLoadService extends Service {
    Handler mHandler = new Handler();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
//                    URL url = new URL("http://img.bizhi.sogou.com/images/2012/09/23/43619.jpg");
//                    InputStream inputStream = url.openStream();
//                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                    int len = 0;
//                    byte[] bytes = new byte[1024];
//                    while ((len = inputStream.read(bytes)) != -1) {
//                        baos.write(bytes, 0, len);
//                    }
//                    final byte[] data = baos.toByteArray();






                    AssetManager assets = getAssets();
                    InputStream open = assets.open("b1.png");

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    int len;
                    byte[] bytes = new byte[1024];
                    while ((len = open.read(bytes)) != -1) {
                        baos.write(bytes, 0, len);
                    }
                    final byte[] data = baos.toByteArray();


                    //Activity
                    //广播
                    Intent intent1 = new Intent("tcmp058__666");
//                    intent1.setAction("tcmp058__666")
                    intent1.putExtra("data", data);

                    sendBroadcast(intent1);

                    //不能显示  1:子线程不能更新UI
//                    mHandler.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            //2:不行  Service 所有的工作 都在后台进行
//                            ImageView imageView = new ImageView(DownLoadService.this);
//                            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
//                            imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
//                            imageView.setImageBitmap(bitmap);
//                        }
//                    });
//
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();


        return super.onStartCommand(intent, flags, startId);

    }
}

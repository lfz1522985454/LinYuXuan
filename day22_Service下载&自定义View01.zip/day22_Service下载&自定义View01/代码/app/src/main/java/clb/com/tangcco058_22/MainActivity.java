package clb.com.tangcco058_22;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    MyReceiver mMyReceiver;
    private ImageView image_down;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image_down = (ImageView) findViewById(R.id.image_down);
        mMyReceiver = new MyReceiver();
    }

    public void start(View view) {
        Intent intent = new Intent(this, DownLoadService.class);
        startService(intent);
    }

    class MyReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            byte[] datas = intent.getByteArrayExtra("data");
            Bitmap bitmap = BitmapFactory.decodeByteArray(datas, 0, datas.length);
            image_down.setImageBitmap(bitmap);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("tcmp058__666");
        registerReceiver(mMyReceiver, intentFilter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mMyReceiver != null) {
            unregisterReceiver(mMyReceiver);
        }

    }
}

package clb.com.tangcco058_22;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import clb.com.tangcco058_22.weight.MyView01;

public class ViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyView01 myView01 = new MyView01(this);


//        setContentView(R.layout.activity_view);
        setContentView(myView01);
    }
}

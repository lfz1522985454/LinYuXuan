package clb.com.tangcco058_22.weight;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;

import clb.com.tangcco058_22.R;

/**
 * Created by cuilibao on 2017/9/26.
 */

public class MyView01 extends View {

    int positionY = 0;
    int position = 0;
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            invalidate();
        }
    };
    private Paint mPaint;
    private RectF mRectF;
    private Bitmap mBitmap;

    /**
     * new MyView()
     *
     * @param context
     */
    public MyView01(Context context) {
        super(context);
        init();
    }

    /**
     * xml 生成的时候调用
     *
     * @param context
     * @param attrs   属性
     */
    public MyView01(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    /**
     * @param context
     * @param attrs
     * @param defStyleAttr 主题
     */
    public MyView01(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();

    }

    private void init() {
        //初始化 画笔
        mPaint = new Paint();
        //颜色
        mPaint.setColor(Color.RED);
        //Stroke 笔尖
        mPaint.setStrokeWidth(10);

        //Paint.Style.FILL 填充   Paint.Style.STROKE
        mPaint.setStyle(Paint.Style.FILL);
        //mPaint.setAntiAlias(true);//笔尖拐弯儿处圆滑

        mRectF = new RectF();
        mBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.linfangzheng2);

    }

    /**
     * 绘制的时候调用
     *
     * @param canvas 画布
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.setColor(Color.RED);
        position += 5;
        //开始画
        //头  Rect 矩形  shape  shape="Oval"  "Rect"

        mRectF.set(20, 20 + positionY, 400, 400 + positionY);
        //canvas.drawRect(mRectF, mPaint);

        //圆
        canvas.drawOval(mRectF, mPaint);

        mPaint.setColor(Color.BLUE);
        canvas.drawLine(20, 380, 500, 380, mPaint);

        canvas.drawBitmap(mBitmap, 400, 600, mPaint);
        //canvas.drawText("dddd", 100, 600, mPaint);
        // invalidate 在主线程调用
        //  postInvalidate 子线程
        if (position > 500) {
            positionY -= 5;


        } else {

            positionY += 5;
        }

        mHandler.sendEmptyMessageDelayed(0, 100);//Delayed 延时

    }
}

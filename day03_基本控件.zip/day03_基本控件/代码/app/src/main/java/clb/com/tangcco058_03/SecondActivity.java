package clb.com.tangcco058_03;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by cuilibao on 2017/8/11.
 */

public class SecondActivity extends Activity implements View.OnClickListener {
    int i = 0;
    private Button btn_pre, btn_next;
    private ImageView image_head;
    private EditText edit_name, edit_pwd;
    private int imgs[] = {R.mipmap.b1, R.mipmap.e1, R.mipmap.h1, R.mipmap.i1};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zonghe_layout);
        btn_pre = (Button) findViewById(R.id.btn_pre);
        btn_next = (Button) findViewById(R.id.btn_next);
        edit_name = (EditText) findViewById(R.id.edit_name);
        edit_pwd = (EditText) findViewById(R.id.edit_pwd);
        image_head = (ImageView) findViewById(R.id.image_head);
        //btn_submit = (Button) findViewById(R.id.);

        btn_pre.setOnClickListener(this);
        btn_next.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_pre:
                //上一张
                //换图片
                i--;
                if (i < 0) {
                    i = imgs.length - 1;
                }
                image_head.setImageResource(imgs[i]);

                //设置背景颜色
                v.setBackgroundColor(Color.RED);



                break;
            case R.id.btn_next:
                //下一张
                i++;
                if (i > imgs.length - 1) {
                    i = 0;
                }
                image_head.setImageResource(imgs[i]);
                break;

        }
    }

    public void submit(View view) {

        //提交
        String name = edit_name.getText().toString();
        String pwd = edit_pwd.getText().toString();
        if (name.length() == 0 || pwd.length() == 0) {
            Toast.makeText(this, "请输入完整信息..", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();


        //意图
        Intent intent = new Intent(this, ShowActivity.class);


        intent.putExtra("name", name);
        intent.putExtra("pwd", pwd);

        //启动一个Activity
        startActivity(intent);

    }
}

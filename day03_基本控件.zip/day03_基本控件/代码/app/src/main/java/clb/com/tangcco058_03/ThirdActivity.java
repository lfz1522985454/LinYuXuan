package clb.com.tangcco058_03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class ThirdActivity extends AppCompatActivity {
    LinearLayout linear_1,linear_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        linear_1 = (LinearLayout) findViewById(R.id.linear_1);
        linear_2 = (LinearLayout) findViewById(R.id.linear_2);
    }

    public void zhuce(View view) {
        linear_1.setVisibility(View.VISIBLE);
        linear_2.setVisibility(View.GONE);

    }

    public void login(View view) {
        linear_1.setVisibility(View.GONE);
        linear_2.setVisibility(View.VISIBLE);
    }
}

package clb.com.tangcco058_03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //1:
    private Button btn_1;
    private Button btn_3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //2:
        btn_1 = (Button) findViewById(R.id.btn_1);
        btn_3 = (Button) findViewById(R.id.btn_3);

        //3:点击事件
        //3.1:内部类的方式
        //观察者模式
//        btn_1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "按钮1", Toast.LENGTH_SHORT).show();
//            }
//        });
        //3.3
        btn_1.setOnClickListener(this);
        btn_3.setOnClickListener(this);

    }


    //3.2
    public void haha(View view) {
        Toast.makeText(this, "按钮2", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {//Button
        //找到按钮的id
        switch (v.getId()) {
            case R.id.btn_1:
                Toast.makeText(this, "按钮1", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn_3:
                Toast.makeText(this, "按钮3", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}

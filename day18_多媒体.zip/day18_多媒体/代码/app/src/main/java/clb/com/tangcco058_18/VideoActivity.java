package clb.com.tangcco058_18;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import java.io.File;

public class VideoActivity extends AppCompatActivity {
    private VideoView mVideoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        mVideoView = (VideoView) findViewById(R.id.mVideoView);

        //6.0

        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "0032" + File.separator + "jump.mp4";

        //1:
        mVideoView.setVideoPath(path);
        //家进度条
        //1:获取时间
        //2:凯子线程
        //3:设置时间
        //4:format
        mVideoView.setMediaController(new MediaController(this));

        mVideoView.start();

    }
}

package clb.com.tangcco058_18;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    //1:创建mp对象
    MediaPlayer mMediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //2:进入空白状态
        mMediaPlayer = new MediaPlayer();
        //mMediaPlayer.setDataSource();//url  path

        //方法①  直接进入准备状态
        //mMediaPlayer = MediaPlayer.create(this, R.raw.earth);
        initDataSource();
    }

    private void initDataSource() {
        //方法②
        try {
            mMediaPlayer.setDataSource("http://cdnbbbd.shoujiduoduo.com/bb/audio/a48/766/703766.aac");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //异步的准备
        mMediaPlayer.prepareAsync();

        //设置监听
        mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mMediaPlayer.start();
            }
        });
    }

    public void start(View view) {
        mMediaPlayer.start();
    }

    public void stop(View view) {
        //mMediaPlayer.isPlaying() 是否正在播放
        if (mMediaPlayer.isPlaying()) {
            mMediaPlayer.stop();
            try {
                mMediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}

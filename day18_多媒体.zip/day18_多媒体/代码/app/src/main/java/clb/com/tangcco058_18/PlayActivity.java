package clb.com.tangcco058_18;


import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PlayActivity extends AppCompatActivity {
    //1:创建mp对象
    MediaPlayer mMediaPlayer;
    private SeekBar mSeekBar;
    private boolean flag = true;

    private TextView tv_time;
    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            //0 what
            if (msg.what == 0) {
                //1:更新进度
                mSeekBar.setProgress(mMediaPlayer.getCurrentPosition());
                //当前的时间
                String currentTime = dataFormat(mMediaPlayer.getCurrentPosition());
                String totalTime = dataFormat(mMediaPlayer.getDuration());

                //2:更新时间
                tv_time.setText(currentTime + "/" + totalTime);
            }

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        tv_time = (TextView) findViewById(R.id.tv_time);
        //mSeekBar setMax()  设置最大进度 歌曲的总时间
        //mSeekBar.setProgress(); 设置当前进度  歌曲正在播放的时间
        //2:进入空白状态
        mMediaPlayer = new MediaPlayer();

        mMediaPlayer = MediaPlayer.create(this, R.raw.earth);

        mSeekBar.setMax(mMediaPlayer.getDuration());
        //mMediaPlayer.getDuration();总时间 long
        //mMediaPlayer.getCurrentPosition();// mm:ss
        MyThread myThread = new MyThread();
        myThread.start();


        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            /**
             * 进度改掉
             * @param seekBar
             * @param progress
             * @param fromUser
             */
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //int progress = seekBar.getProgress();
                tv_time.setText(dataFormat(progress) + "/" + dataFormat(mMediaPlayer.getDuration()));
            }

            /**
             * 手指头拖动时调用
             * @param seekBar
             */
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            /**
             * 拖动后调用
             * @param seekBar
             */
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //1:将拖动后的位置 设置mediaplayer的时间
                mMediaPlayer.seekTo(seekBar.getProgress());
            }
        });
    }
    //1:创建一个子线程:每个500毫秒 run -->发送到主线程  500  更新页面
    //2:时间  格式化

    public void start(View view) {
        if (mMediaPlayer.isPlaying()) {
            //暂停
            mMediaPlayer.pause();
        } else {
            mMediaPlayer.start();
        }
    }

    public String dataFormat(long time) {
        SimpleDateFormat format = new SimpleDateFormat("mm:ss");
        return format.format(new Date(time));
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        flag = false;
    }

    class MyThread extends Thread {
        @Override
        public void run() {
            super.run();
            while (flag) {
                //每隔500ms发送消息到主线程
                //进度条 时间
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mHandler.sendEmptyMessage(0);
            }
        }
    }
}
